ROZ 02 - Michal Haindl 2023-2024
Open p02/index.html or p02/commented.html. Both editions and original PDF are included. Keep shared/ and p02/ next to each other.
