#include "lab.hpp"
int main(int argc,char** argv){try{roz::demo("affine",argc>1?argv[1]:"data/auto-mpg-50.csv");return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
