import json
from pathlib import Path
from lab import run_demo, json_value
print(json.dumps(json_value(run_demo("gradient",Path(__file__).parent/"data/auto-mpg-50.csv")),indent=2,allow_nan=False))
