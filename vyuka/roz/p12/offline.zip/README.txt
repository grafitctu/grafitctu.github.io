ROZ 12 - Michal Haindl 2023-2024
Open p12/index.html or p12/commented.html. Both editions and original PDF are included. Keep shared/ and p12/ next to each other.
