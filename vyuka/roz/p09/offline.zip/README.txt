ROZ 09 - Michal Haindl 2023-2024
Open p09/index.html or p09/commented.html. Both editions and original PDF are included. Keep shared/ and p09/ next to each other.
