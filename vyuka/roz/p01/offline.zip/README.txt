ROZ 01 - Michal Haindl 2023-2024
Open p01/index.html or p01/commented.html. Both editions and original PDF are included. Keep shared/ and p01/ next to each other.
