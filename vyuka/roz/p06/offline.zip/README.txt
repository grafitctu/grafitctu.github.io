ROZ 06 - Michal Haindl 2023-2024
Open p06/index.html or p06/commented.html. Both editions and original PDF are included. Keep shared/ and p06/ next to each other.
