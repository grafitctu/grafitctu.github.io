ROZ 03 - Michal Haindl 2023-2024
Open p03/index.html or p03/commented.html. Both editions and original PDF are included. Keep shared/ and p03/ next to each other.
