cmake_minimum_required(VERSION 3.16)
project(moments LANGUAGES CXX)
add_executable(moments moments.cpp)
target_compile_features(moments PRIVATE cxx_std_17)
