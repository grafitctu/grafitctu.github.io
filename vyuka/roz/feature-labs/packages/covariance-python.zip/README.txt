NI-ROZ / ANI-ROZ · covariance

Příkazy spouštějte z rozbalené složky.
Run commands from the extracted folder.
Python 3
  python covariance.py

Vstupní příklad je v hlavní funkci. Upravte jeho hodnoty a program spusťte znovu.
The input example is in the main block. Edit its values and run the program again.

https://grafitctu.github.io/vyuka/roz/feature-labs/
