Od jedné šipky k PCA / From one arrow to PCA

Rozbalte oba soubory do jedné složky a spusťte příklad v této složce. Sedm částí programu odpovídá sedmi krokům ve cvičení.
Extract the files into one folder and run the example there. The seven sections of the program match the seven steps in the workshop.

Python 3
python pca_steps.py

V kroku 3 porovnejte vždy tutéž šipku. Sloupce výstupu patří směrům 45° a 135°. Matice A dává násobky 2 a 0,5, B dává 3 a 1 a matice 3I dává 3 v každém směru.
In step 3 compare the same arrow each time. The output columns correspond to 45° and 135°. The factors are 2 and 0.5 for A, 3 and 1 for B, and 3 in every direction for 3I.

CSV obsahuje 64 modelových měření. Centrované odchylky výšky dělíme 5 cm a hmotnosti 4 kg. Výběrová kovariance má na diagonále 1,25 a mimo ni 0,75. Skóre prvního bodu na PC1 je √2.
The CSV contains 64 synthetic measurements. Divide the centred height deviations by 5 cm and weight deviations by 4 kg. Sample covariance has 1.25 on the diagonal and 0.75 off it. The first PC1 score is √2.
