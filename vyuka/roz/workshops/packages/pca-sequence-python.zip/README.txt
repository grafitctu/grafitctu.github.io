Od jedné šipky k PCA / From one arrow to PCA

Rozbalte oba soubory do jedné složky a spusťte příklad v této složce. Sedm částí programu odpovídá sedmi krokům ve cvičení.
Extract the files into one folder and run the example there. The seven sections of the program match the seven steps in the workshop.

Python 3
python pca_steps.py

CSV obsahuje 64 modelových měření. Centrované odchylky výšky dělíme 5 cm a hmotnosti 4 kg. Výběrová kovariance má na diagonále 1,25 a mimo ni 0,75. Skóre prvního bodu na PC1 je √2.
The CSV contains 64 synthetic measurements. Divide the centred height deviations by 5 cm and weight deviations by 4 kg. Sample covariance has 1.25 on the diagonal and 0.75 off it. The first PC1 score is √2.

GraduateML · https://www.instagram.com/reels/DfLGLOSJ5ob/
