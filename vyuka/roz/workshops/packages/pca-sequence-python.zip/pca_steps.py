import csv
import math
import sys


# 1. Matrix times vector
def transform(matrix, vector):
    x, y = vector
    return tuple(row[0] * x + row[1] * y for row in matrix)


# 2. Test an eigendirection
def direction_error(matrix, u):
    ax, ay = transform(matrix, u)
    # The determinant of the two arrows is zero when they lie on one line.
    return abs(u[0] * ay - u[1] * ax)


# 3. Measure the stretch along an eigendirection
def stretch(matrix, u):
    # For a nonzero eigenvector this length ratio gives the absolute eigenvalue.
    ax, ay = transform(matrix, u)
    return math.hypot(ax, ay) / math.hypot(*u)


def print_stretches(name, matrix):
    # All three matrices share these eigenlines. Normalising the arrows gives the same ratios.
    first = stretch(matrix, (1, 1))
    second = stretch(matrix, (-1, 1))
    print(f"3  stretch {name}  {first:.6f} {second:.6f}")


# 4. Centre height and weight, then calculate sample covariance
def covariance(measurements, show_work=False):
    n = len(measurements)
    mean_h = sum(h for h, w in measurements) / n
    mean_w = sum(w for h, w in measurements) / n
    deviations = [(h - mean_h, w - mean_w) for h, w in measurements]
    points = [(dh / 5, dw / 4) for dh, dw in deviations]
    sum_hh = sum(h * h for h, w in points)
    sum_hw = sum(h * w for h, w in points)
    sum_ww = sum(w * w for h, w in points)
    if show_work:
        print(f"4  mean (cm, kg)  {mean_h:.6f} {mean_w:.6f}")
        dh, dw = deviations[0]
        h, w = points[0]
        print(f"4  first deviations (cm, kg)  {dh:.6f} {dw:.6f}")
        print(f"4  first scaled point (h, w)  {h:.6f} {w:.6f}")
        print(f"4  sums (hh, hw, ww)  {sum_hh:.6f} {sum_hw:.6f} {sum_ww:.6f}  divisor {n-1}")
    hh, hw, ww = sum_hh / (n - 1), sum_hw / (n - 1), sum_ww / (n - 1)
    return points, ((hh, hw), (hw, ww))


# 5. Find the principal axes of the symmetric covariance matrix
def principal_axes(matrix):
    (a, b), (_, d) = matrix
    gap = math.hypot(a - d, 2 * b)
    eigenvalues = ((a + d + gap) / 2, (a + d - gap) / 2)
    angle = math.atan2(2 * b, a - d) / 2
    pc1 = (math.cos(angle), math.sin(angle))
    pc2 = (-pc1[1], pc1[0])
    return eigenvalues, pc1, pc2


# 6. Project each centred point onto a unit axis
def project(points, axis):
    return [h * axis[0] + w * axis[1] for h, w in points]


# 7. Count the one-dimensional scores in equal-width bins
def histogram(scores, bins):
    low, high = min(scores), max(scores)
    counts = [0] * bins
    for score in scores:
        relative = (score - low) / (high - low) if high > low else 0
        index = min(int(relative * bins), bins - 1)
        counts[index] += 1
    return counts


# Run all seven steps
def main(filename):
    with open(filename, newline="", encoding="utf8") as file:
        measurements = [(float(r["height_cm"]), float(r["weight_kg"])) for r in csv.DictReader(file)]
    if len(measurements) < 2:
        raise ValueError("Supply at least two measurements")
    matrix = ((1.25, 0.75), (0.75, 1.25))
    print("1  Av", *(f"{v:.6f}" for v in transform(matrix, (2, -0.5))))
    q = 1 / math.sqrt(2)
    for u in [(q, q), (-q, q)]:
        print("2  direction error", f"{direction_error(matrix, u):.6f}")
    print_stretches("A", matrix)
    print_stretches("B", ((2, 1), (1, 2)))
    print_stretches("3I", ((3, 0), (0, 3)))
    points, cov = covariance(measurements, show_work=True)
    print("4  covariance", *(f"{v:.6f}" for row in cov for v in row))
    values, pc1, pc2 = principal_axes(cov)
    print("5  eigenvalues", *(f"{v:.6f}" for v in values))
    scores = project(points, pc1)
    print("6  first PC1 score", f"{scores[0]:.6f}")
    print("7  bin counts", *histogram(scores, 10))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "measurements.csv")
