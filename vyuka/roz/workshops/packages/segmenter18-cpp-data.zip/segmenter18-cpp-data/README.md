# Segmenter 18 — C++ code, XML and sample data

## Česky

Balík pro NI-ROZ / ANI-ROZ obsahuje zdrojové kódy v C++, konfigurace XML,
pět mozaik a 16 fotografií BSDS. Starou binární knihovnu VR nahrazuje zdrojový
kód. Neobsahuje předem přeložený program; potřebujete překladač s podporou C++17.

### Windows a Visual Studio Code

1. Rozbalte celý ZIP a ve VS Code otevřete složku `segmenter18-cpp-data`.
2. Nainstalujte rozšíření **C/C++ od Microsoftu** a **Visual Studio 2022** nebo
   **Build Tools** se sadou **Desktop development with C++**. Samotné VS Code
   překladač neobsahuje. Připravený skript instalaci překladače vyhledá automaticky.
3. V nabídce Run and Debug vyberte **Run C++ segmenter (choose XML)** a stiskněte
   **F5**. Program se přeloží a v záložce **Terminal** nabídne XML soubory.
4. Na řádku `XML>` zadejte číslo, například `1`, nebo název, například `bsds.xml`,
   a stiskněte Enter. Volbu zadávejte do Terminal, ne do Debug Console.

### Linux / MinGW

Z kořenové složky balíku spusťte:

```sh
make
./segmenter
```

Na Windows s MSVC lze překlad spustit také příkazem
`.vscode\build-msvc.cmd` a potom `.\segmenter.exe`.

### Výběr dat a výsledky

| XML | Co zpracuje | Výsledky |
| --- | --- | --- |
| `segmenter-smoke.xml` | Jednu mozaiku; rychlá kontrola spuštění | `smoke/seg.png`, `smoke/overlay.png`, `smoke/edges.png` |
| `segmenter.xml` | Všech pět přiložených mozaik | `results/` |
| `bsds.xml` | Všech 16 přiložených fotografií | `bsds/seg_*.png`, `bsds/emb_*.jpg`, `bsds/edge_*.png` |
| `colour_large.xml` | Plný benchmark s 80 mozaikami; data nejsou v tomto ZIPu | `results/` |

Pro jiný balík zadejte cestu k jeho XML. Relativní cesty k obrázkům a výstupům
se počítají od složky vybraného XML. Při chybné volbě se program zeptá znovu;
`q` výběr zruší. XML lze předat i přímo: `.\segmenter.exe bsds.xml` nebo
`./segmenter bsds.xml`. V tom případě se program na konfiguraci neptá.

Výpis v terminálu potvrzuje načtení obrázků, kroky segmentace a uložení souborů.
Zůstává také v `segmenter-run.log` ve složce, ze které byl program spuštěn.
`SUCCESS` znamená, že se zpracovaly a uložily všechny obrázky uvedené v XML,
nikoli že segmentace má dobrou přesnost. Při chybě čtení nebo ukládání se běh zastaví.

Mapa `seg*.png` obsahuje přímo čísla tříd, proto může v běžném prohlížeči vypadat
skoro černá. Pro rychlou vizuální kontrolu otevřete obrázek s hranicemi: ve smoke
testu `smoke/overlay.png`, v BSDS `bsds/emb_*.jpg`, u mozaik `results/emb*.png`.

### Co mají studenti upravovat

Základní příznaky počítá `Segmenter::features()` v `Segmenter.cpp`.
Výpočet je záměrně jednoduchý a má být vylepšen. Vlastní implementaci lze také
napsat do připravené `MySegmenter::features()` v `main.cpp`; nejdřív odkomentujte
její deklaraci a tělo. Obsluhu XML a souborů najdete odděleně od výpočtu příznaků.

Pro Mosaic použijte celou odpovídající benchmarkovou sadu a její parametry.
Pět ukázkových mozaik ani BSDS nenahrazují 80obrázkový benchmark. Historický
`readme.txt` uvádí odkaz na plná data; aktuální postup ověřte na
[stránce cvičení](https://courses.fit.cvut.cz/NI-ROZ/tutorials/02/index.html)
a v pokynech Mosaic. Tento ZIP je balík kódů a vstupních dat, ne ZIP výsledků
pro odevzdání na Mosaic.

## English

This NI-ROZ / ANI-ROZ package contains C++ source code, XML configurations,
five texture mosaics and 16 BSDS photographs. It replaces the old precompiled
VR library with source code. No executable is included; a C++17 compiler is required.

### Windows and Visual Studio Code

1. Extract the whole ZIP and open the `segmenter18-cpp-data` folder in VS Code.
2. Install Microsoft's **C/C++ extension** and **Visual Studio 2022** or
   **Build Tools** with **Desktop development with C++**. VS Code alone is not
   a compiler. The supplied build script locates the installed tools automatically.
3. Select **Run C++ segmenter (choose XML)** under Run and Debug and press **F5**.
   The program builds and lists XML configurations in the **Terminal**.
4. At `XML>`, enter a menu number or a filename such as `bsds.xml`, then press
   Enter. Use the Terminal, not the Debug Console, for input.

### Linux / MinGW

Run `make` and then `./segmenter` from the package directory. On Windows with
MSVC, `.vscode\build-msvc.cmd` builds the program; `.\segmenter.exe` runs it.

### Dataset selection and outputs

| XML | Input dataset | Outputs |
| --- | --- | --- |
| `segmenter-smoke.xml` | One mosaic; a quick startup check | `smoke/seg.png`, `smoke/overlay.png`, `smoke/edges.png` |
| `segmenter.xml` | All five included mosaics | `results/` |
| `bsds.xml` | All 16 included photographs | `bsds/seg_*.png`, `bsds/emb_*.jpg`, `bsds/edge_*.png` |
| `colour_large.xml` | The full 80-mosaic benchmark; its data are not included | `results/` |

For another dataset, enter the path to its XML. Relative image and output paths
are resolved from that XML's directory. Invalid choices ask again; `q` cancels.
You can also pass the XML directly, e.g. `./segmenter bsds.xml` or
`.\segmenter.exe bsds.xml`, to skip the question.

The Terminal shows image loading, processing stages and saved files. These
messages also remain in `segmenter-run.log` in the launch directory. `SUCCESS`
means all configured images were processed and saved, not that the segmentation
is accurate. Read/write errors stop the run.

The `seg*.png` files store raw class numbers and can look almost black in an
ordinary image viewer. Inspect the border overlays instead: `smoke/overlay.png`,
`bsds/emb_*.jpg` or `results/emb*.png`, depending on your configuration.

### Student work

The intentionally simple feature calculation is `Segmenter::features()` in
`Segmenter.cpp`. Improve it, or implement the prepared `MySegmenter::features()`
override in `main.cpp` after uncommenting its declaration and body. XML and file
handling are separate from the feature calculation.

Mosaic submission requires the full matching benchmark dataset and its parameters.
The five sample mosaics and BSDS photographs are not the 80-image benchmark.
The preserved historical `readme.txt` includes the full-data link; check the
[tutorial page](https://courses.fit.cvut.cz/NI-ROZ/tutorials/02/index.html)
and Mosaic instructions for the applicable submission procedure. This download
contains code and input data, not a Mosaic submission archive.

## Provenance and checks / Původ a kontroly

The original CVUT README is preserved as `readme.txt`; implementation details
and compatibility limits are in `PORTABLE_README.md`. The stb headers retain
their embedded licence notices. The BSDS XML uses the supplied JPEG dimensions:
`138078.jpg` and `157036.jpg` have 482 columns, the other photographs have 481.
The image files themselves have not been resized or modified.

`MANIFEST.json` records SHA-256 hashes of the packaged files. After building,
PowerShell 7 can run `./tests/check-startup.ps1` to check dataset selection and
error handling. Add `-FullDatasets` to process all five mosaics and all 16 BSDS
photographs. These checks do not establish equivalence with the historical
binary or benchmark accuracy.
