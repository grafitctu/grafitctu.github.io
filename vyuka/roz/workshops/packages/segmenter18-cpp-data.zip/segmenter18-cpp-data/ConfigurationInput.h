// Keep dataset selection separate from the student segmentation code.
#ifndef SEGMENTER_CONFIGURATION_INPUT_H
#define SEGMENTER_CONFIGURATION_INPUT_H

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>
#include "RuntimeLog.h"

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace segmenter_startup {

// The terminal and redirected stdin use UTF-8. Restore the caller's console settings.
class ConsoleEncoding {
#if defined(_WIN32)
  const unsigned input_page = GetConsoleCP();
  const unsigned output_page = GetConsoleOutputCP();
#endif
public:
  ConsoleEncoding() {
#if defined(_WIN32)
    if (input_page) SetConsoleCP(CP_UTF8);
    if (output_page) SetConsoleOutputCP(CP_UTF8);
#endif
  }
  ~ConsoleEncoding() {
#if defined(_WIN32)
    if (input_page) SetConsoleCP(input_page);
    if (output_page) SetConsoleOutputCP(output_page);
#endif
  }
};

enum class Selection { selected, cancelled, error };

inline std::string trim_input(const std::string &input) {
  const auto first = input.find_first_not_of(" \t\r\n");
  if (first == std::string::npos) return {};
  const auto last = input.find_last_not_of(" \t\r\n");
  std::string result = input.substr(first, last - first + 1);
  if (result.size() >= 2 &&
      ((result.front() == '"' && result.back() == '"') ||
       (result.front() == '\'' && result.back() == '\'')))
    result = result.substr(1, result.size() - 2);
  return result;
}

inline bool existing_configuration(const std::filesystem::path &candidate,
                                   std::filesystem::path &config) {
  std::error_code error;
  if (!std::filesystem::is_regular_file(candidate, error)) {
    segmenter_logging::error("ERROR: XML file does not exist or is not a regular file: %s\n",
      candidate.u8string().c_str());
    return false;
  }
  config = std::filesystem::absolute(candidate).lexically_normal();
  return true;
}

inline Selection select_configuration(int argc, char *argv[],
                                      std::filesystem::path &config) {
  if (argc > 2) {
    segmenter_logging::error("Usage: segmenter [configuration.xml]\n");
    return Selection::error;
  }
  if (argc == 2) {
    const std::string argument = argv[1];
    if (argument == "--help" || argument == "-h") {
      segmenter_logging::info(
        "Usage: segmenter [configuration.xml]\n"
        "Without an argument, choose an XML file interactively.\n"
        "Image and output paths are relative to the selected XML directory.\n");
      return Selection::cancelled;
    }
    return existing_configuration(std::filesystem::path(trim_input(argument)), config)
      ? Selection::selected : Selection::error;
  }

  std::vector<std::filesystem::path> configurations;
  for (const auto &entry : std::filesystem::directory_iterator(std::filesystem::current_path())) {
    std::string extension = entry.path().extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(),
      [](unsigned char character) { return static_cast<char>(std::tolower(character)); });
    if (entry.is_regular_file() && extension == ".xml")
      configurations.push_back(entry.path());
  }
  std::sort(configurations.begin(), configurations.end());
  segmenter_logging::info("\nChoose the dataset XML / Vyberte XML datove sady:\n");
  for (std::size_t index = 0; index < configurations.size(); ++index)
    segmenter_logging::info("  %zu) %s\n", index + 1,
      configurations[index].filename().u8string().c_str());
  if (configurations.empty())
    segmenter_logging::info("  No XML files in this directory. Enter a path to your configuration.\n");
  segmenter_logging::info("Enter a number or an XML path (spaces allowed); q = quit.\n");

  for (;;) {
    segmenter_logging::info("XML> ");
    std::string input;
    if (!std::getline(std::cin, input)) {
      segmenter_logging::error(
        "\nERROR: standard input is closed; no XML was selected.\n"
        "Use a terminal or pass the XML as an argument: segmenter configuration.xml\n");
      return Selection::error;
    }
    input = trim_input(input);
    if (input == "q" || input == "Q") {
      segmenter_logging::info("Cancelled. No images were processed.\n");
      return Selection::cancelled;
    }
    if (input.empty()) {
      segmenter_logging::info("Please choose an XML file; Enter alone does not start segmentation.\n");
      continue;
    }
    const bool numeric = std::all_of(input.begin(), input.end(),
      [](unsigned char character) { return std::isdigit(character) != 0; });
    if (numeric) {
      // Compare strings instead of parsing an unbounded number supplied by the user.
      const auto first_digit = input.find_first_not_of('0');
      const std::string number = first_digit == std::string::npos ? "0" : input.substr(first_digit);
      for (std::size_t index = 0; index < configurations.size(); ++index) {
        if (number == std::to_string(index + 1)) {
          config = configurations[index];
          return Selection::selected;
        }
      }
      segmenter_logging::error("ERROR: choose one of the listed numbers or enter an XML path.\n");
      continue;
    }
    if (existing_configuration(std::filesystem::u8path(input), config))
      return Selection::selected;
  }
}

}  // namespace segmenter_startup

#endif
