#requires -Version 7.0
# Run from PowerShell after building segmenter.exe. All outputs stay in the package.
param([switch]$FullDatasets)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$executable = Join-Path $projectRoot 'segmenter.exe'

function Invoke-StartupCheck {
    param(
        [string]$Name,
        [string[]]$Parameters = @(),
        [string]$InputText = '',
        [int]$ExpectedExit = 0,
        [int]$CompletedImages = 0,
        [string]$ExpectedText = '',
        [bool]$ExpectPrompt = $true,
        [string]$WorkingDirectory = $projectRoot
    )
    $processInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $processInfo.FileName = $executable
    $processInfo.WorkingDirectory = $WorkingDirectory
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.RedirectStandardInput = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.RedirectStandardError = $true
    $processInfo.StandardInputEncoding = [System.Text.UTF8Encoding]::new($false)
    $processInfo.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $processInfo.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    foreach ($parameter in $Parameters) { $processInfo.ArgumentList.Add($parameter) }
    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $processInfo
    try {
        if (-not $process.Start()) { throw "Cannot start $executable" }
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if ($InputText) { $process.StandardInput.Write($InputText) }
        $process.StandardInput.Close()
        $deadline = [DateTime]::UtcNow.AddMinutes(3)
        while (-not $process.WaitForExit(1000)) {
            if ([DateTime]::UtcNow -ge $deadline) {
                $process.Kill()
                throw "$Name exceeded three minutes."
            }
        }
        $output = $stdout.GetAwaiter().GetResult() + $stderr.GetAwaiter().GetResult()
        if ($process.ExitCode -ne $ExpectedExit) {
            $tail = ($output -split "`n" | Select-Object -Last 20) -join "`n"
            throw "$Name returned $($process.ExitCode), expected $ExpectedExit.`n$tail"
        }
        if ($output.Contains('XML>') -ne $ExpectPrompt) {
            throw "$Name had an unexpected prompt state.`n$output"
        }
        if ($ExpectedText -and -not $output.Contains($ExpectedText)) {
            throw "$Name did not print '$ExpectedText'.`n$output"
        }
        if ($CompletedImages -gt 0) {
            if (-not $output.Contains("SUCCESS: processed and saved $CompletedImages image(s)")) {
                throw "$Name did not complete the expected dataset.`n$output"
            }
            if ([regex]::Matches($output, '(?m)^Run \d+/').Count -ne $CompletedImages) {
                throw "$Name processed the wrong number of images.`n$output"
            }
        } elseif ($output -match '(?m)^SUCCESS:') {
            throw "$Name falsely reported successful segmentation.`n$output"
        }
        Write-Host "PASS: $Name (exit $($process.ExitCode), images $CompletedImages)"
    } finally {
        $process.Dispose()
    }
}

$xmlFiles = @(Get-ChildItem -LiteralPath $projectRoot -File -Filter '*.xml' | Sort-Object FullName)
$smokeFile = $xmlFiles | Where-Object Name -eq 'segmenter-smoke.xml'
$smokeNumber = [array]::IndexOf($xmlFiles, $smokeFile) + 1
if ($smokeNumber -le 0) { throw 'Smoke XML is not in the menu.' }
Invoke-StartupCheck -Name 'reference smoke from a clean package' -Parameters @('segmenter-smoke.xml') -CompletedImages 1 -ExpectPrompt $false
$smokeHash = (Get-FileHash -LiteralPath (Join-Path $projectRoot 'smoke/seg.png')).Hash

Invoke-StartupCheck -Name 'choose by menu number' -InputText "$smokeNumber`n" -CompletedImages 1
Invoke-StartupCheck -Name 'choose by filename' -InputText "segmenter-smoke.xml`n" -CompletedImages 1
Invoke-StartupCheck -Name 'absolute XML path entered on stdin' -InputText "$(Join-Path $projectRoot 'segmenter-smoke.xml')`n" -CompletedImages 1
Invoke-StartupCheck -Name 'invalid choices ask again' -InputText "`n999999999999999999999999999`nnot-here.xml`nsegmenter-smoke.xml`n" -CompletedImages 1 -ExpectedText 'Enter alone does not start segmentation'
Invoke-StartupCheck -Name 'quoted filename with spaces in another directory' -InputText "`"tests/fixtures/config with spaces.xml`"`n" -CompletedImages 1 -ExpectedText 'config with spaces.xml'
Invoke-StartupCheck -Name 'XML argument bypasses prompt' -Parameters @('segmenter-smoke.xml') -CompletedImages 1 -ExpectPrompt $false
Invoke-StartupCheck -Name 'absolute XML argument' -Parameters @((Join-Path $projectRoot 'segmenter-smoke.xml')) -CompletedImages 1 -ExpectPrompt $false
Invoke-StartupCheck -Name 'cancel' -InputText "q`n" -ExpectedText 'Cancelled. No images were processed.'
Invoke-StartupCheck -Name 'closed stdin is explained' -ExpectedExit 1 -ExpectedText 'standard input is closed'
Invoke-StartupCheck -Name 'missing XML argument' -Parameters @('not-here.xml') -ExpectedExit 1 -ExpectPrompt $false -ExpectedText 'XML file does not exist'
Invoke-StartupCheck -Name 'missing input is an error' -Parameters @('smoke/missing-input-test.xml') -ExpectedExit 1 -ExpectPrompt $false -ExpectedText 'ERROR: cannot read image'
Invoke-StartupCheck -Name 'wrong image dimensions are an error' -Parameters @('smoke/wrong-dimensions-test.xml') -ExpectedExit 1 -ExpectPrompt $false -ExpectedText 'XML expects'
Invoke-StartupCheck -Name 'help' -Parameters @('--help') -ExpectPrompt $false -ExpectedText 'Usage: segmenter'
Invoke-StartupCheck -Name 'no local XML files, choose a path' -WorkingDirectory $PSScriptRoot -InputText "../segmenter-smoke.xml`n" -CompletedImages 1 -ExpectedText 'No XML files in this directory'

$launch = Get-Content -LiteralPath (Join-Path $projectRoot '.vscode/launch.json') -Raw | ConvertFrom-Json
if ($launch.configurations[0].console -ne 'integratedTerminal' -or $launch.configurations[0].args.Count -ne 0) {
    throw 'F5 must use a terminal and no fixed XML argument.'
}
$tasks = Get-Content -LiteralPath (Join-Path $projectRoot '.vscode/tasks.json') -Raw | ConvertFrom-Json
if (-not ($tasks.tasks | Where-Object label -eq 'Run C++ segmenter (choose XML)')) {
    throw 'Interactive VS Code task is missing.'
}
if ((Get-FileHash -LiteralPath (Join-Path $projectRoot 'smoke/seg.png')).Hash -ne $smokeHash) {
    throw 'Dataset selection changed the smoke segmentation values.'
}
Write-Host 'PASS: VS Code configuration and unchanged smoke segmentation'

if ($FullDatasets) {
    Invoke-StartupCheck -Name 'five Mosaic images selected by filename' -InputText "segmenter.xml`n" -CompletedImages 5
    Invoke-StartupCheck -Name 'sixteen BSDS images selected by filename' -InputText "bsds.xml`n" -CompletedImages 16
} else {
    # Leave a successful run in segmenter-run.log after error-path tests.
    Invoke-StartupCheck -Name 'final successful smoke run' -InputText "segmenter-smoke.xml`n" -CompletedImages 1
}
