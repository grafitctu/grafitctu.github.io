/* Source replacement for the VR functions used by the CVUT segmenter. */

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "third_party/stb/stb_image.h"
#include "third_party/stb/stb_image_write.h"

#include "vr/KMeans.h"
#include "vr/Pres2.h"
#include "vr/TBAlloc.h"
#include "RuntimeLog.h"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <limits>
#include <string>
#include <vector>

namespace {

bool key_is_jpeg(int key) {
  return key == PRES_READ_KEY_JPEG || key == PRES_WRITE_KEY_JPEG;
}

std::vector<std::string> input_candidates(int key, const char *filename) {
  std::vector<std::string> candidates;
  if (!filename || !*filename) return candidates;
  const std::filesystem::path original(filename);
  candidates.push_back(original.string());
  if (original.extension().empty()) {
    if (key_is_jpeg(key)) {
      candidates.push_back((original.string() + ".jpg"));
      candidates.push_back((original.string() + ".jpeg"));
      candidates.push_back((original.string() + ".png"));
    } else {
      candidates.push_back((original.string() + ".png"));
      candidates.push_back((original.string() + ".jpg"));
      candidates.push_back((original.string() + ".jpeg"));
    }
  }
  return candidates;
}

std::string output_name(int key, const char *filename) {
  std::filesystem::path path(filename ? filename : "");
  if (path.extension().empty()) path += key_is_jpeg(key) ? ".jpg" : ".png";
  return path.string();
}

}  // namespace

namespace portable_vr {

int read_image(int key, const char *filename, std::vector<unsigned char> &pixels,
               int &width, int &height, int &channels) {
  int loaded_width = 0;
  int loaded_height = 0;
  int loaded_channels = 0;
  unsigned char *decoded = nullptr;
  std::string used_name;

  for (const std::string &candidate : input_candidates(key, filename)) {
    decoded = stbi_load(candidate.c_str(), &loaded_width, &loaded_height,
                        &loaded_channels, 0);
    if (decoded) {
      used_name = candidate;
      break;
    }
  }
  if (!decoded) {
    segmenter_logging::error("ERROR: cannot read image '%s'. Decoder: %s\n",
      filename ? filename : "(no filename)",
      stbi_failure_reason() ? stbi_failure_reason() : "unknown error");
    return IMGIO_FILE_READ_PROBLEM;
  }

  const std::size_t size = static_cast<std::size_t>(loaded_width) *
                           static_cast<std::size_t>(loaded_height) *
                           static_cast<std::size_t>(loaded_channels);
  pixels.assign(decoded, decoded + size);
  stbi_image_free(decoded);

  width = loaded_width;
  height = loaded_height;
  channels = loaded_channels;
  segmenter_logging::info("  Loaded: %s (%d x %d pixels, %d channels)\n",
    std::filesystem::absolute(used_name).u8string().c_str(), width, height, channels);
  return IMGIO_OK;
}

int write_image(int key, const char *filename, const std::vector<unsigned char> &pixels,
                int width, int height, int channels) {
  if (!filename || width <= 0 || height <= 0 || channels <= 0) return IMGIO_WRONG_PARAMETER;
  const std::string path = output_name(key, filename);
  const std::filesystem::path output(path);
  std::error_code error;
  if (output.has_parent_path()) std::filesystem::create_directories(output.parent_path(), error);
  if (error) {
    segmenter_logging::error("ERROR: cannot create output directory for '%s': %s\n",
      path.c_str(), error.message().c_str());
    return IMGIO_FILE_WRITE_PROBLEM;
  }

  const int output_channels = (channels == 1) ? 1 : 3;
  std::vector<unsigned char> converted(
      static_cast<std::size_t>(width) * static_cast<std::size_t>(height) *
      static_cast<std::size_t>(output_channels));
  for (int r = 0; r < height; ++r) {
    for (int c = 0; c < width; ++c) {
      const std::size_t source_base =
          (static_cast<std::size_t>(r) * static_cast<std::size_t>(width) +
           static_cast<std::size_t>(c)) * static_cast<std::size_t>(channels);
      const std::size_t target_base =
          (static_cast<std::size_t>(r) * static_cast<std::size_t>(width) +
           static_cast<std::size_t>(c)) * static_cast<std::size_t>(output_channels);
      if (output_channels == 1) {
        converted[target_base] = pixels[source_base];
      } else {
        converted[target_base] = pixels[source_base];
        converted[target_base + 1] = pixels[source_base + std::min(1, channels - 1)];
        converted[target_base + 2] = pixels[source_base + std::min(2, channels - 1)];
      }
    }
  }

  const int written = key_is_jpeg(key)
    ? stbi_write_jpg(path.c_str(), width, height, output_channels, converted.data(), 95)
    : stbi_write_png(path.c_str(), width, height, output_channels,
                     converted.data(), width * output_channels);
  if (!written) {
    segmenter_logging::error("ERROR: cannot write image '%s'.\n", path.c_str());
    return IMGIO_FILE_WRITE_PROBLEM;
  }
  segmenter_logging::info("  Saved: %s (%d x %d pixels, %d channels)\n",
    std::filesystem::absolute(output).u8string().c_str(), width, height, output_channels);
  return IMGIO_OK;
}

}  // namespace portable_vr

KMeans::KMeans(int clusters, int rows, int columns, int dimensions)
    : dist(nullptr), changes(nullptr), centers(nullptr), values(nullptr),
      weights(nullptr), card(nullptr), nk(clusters), nr(rows), nc(columns),
      nm(dimensions), arr(nullptr), ind(nullptr) {
  vr_alloc(dist, 0, nk - 1, 0, nr - 1, 0, nc - 1);
  vr_alloc(changes, 0, nk - 1);
  vr_alloc(centers, 0, nk - 1, 0, nm - 1);
  vr_alloc(values, 0, nk - 1, 0, nm - 1);
  vr_alloc(weights, 0, nm - 1);
  vr_alloc(card, 0, nk - 1);
  vr_alloc(arr, 0, nm - 1, 0, nr - 1, 0, nc - 1);
  vr_alloc(ind, 0, nr - 1, 0, nc - 1);
}

KMeans::~KMeans() {
  vr_free(dist, 0, nk - 1, 0, nr - 1, 0, nc - 1);
  vr_free(changes, 0, nk - 1);
  vr_free(centers, 0, nk - 1, 0, nm - 1);
  vr_free(values, 0, nk - 1, 0, nm - 1);
  vr_free(weights, 0, nm - 1);
  vr_free(card, 0, nk - 1);
  vr_free(arr, 0, nm - 1, 0, nr - 1, 0, nc - 1);
  vr_free(ind, 0, nr - 1, 0, nc - 1);
}

int KMeans::initialize(int norm) {
  if (!arr || nk <= 0 || nr <= 0 || nc <= 0 || nm <= 0) return -1;
  const int total = nr * nc;

  for (int j = 0; j < nm; ++j) {
    double mean = 0.0;
    for (int r = 0; r < nr; ++r)
      for (int c = 0; c < nc; ++c) mean += arr[j][r][c];
    mean /= static_cast<double>(total);

    double variance = 0.0;
    for (int r = 0; r < nr; ++r)
      for (int c = 0; c < nc; ++c) {
        const double difference = arr[j][r][c] - mean;
        variance += difference * difference;
      }
    variance /= static_cast<double>(std::max(1, total - 1));
    const double scale = std::sqrt(variance);
    weights[j] = (norm && scale > 1.0e-12) ? static_cast<float>(1.0 / (scale * scale)) : 1.0f;
  }

  for (int k = 0; k < nk; ++k) {
    const int flat = (nk == 1) ? 0 : (k * (total - 1)) / (nk - 1);
    const int row = flat / nc;
    const int column = flat % nc;
    for (int j = 0; j < nm; ++j) centers[k][j] = arr[j][row][column];
    changes[k] = 0.0f;
    card[k] = 0;
  }
  for (int r = 0; r < nr; ++r)
    for (int c = 0; c < nc; ++c) ind[r][c] = -1;
  return 0;
}

int KMeans::compute(int iterations) {
  if (!arr || !centers || !ind || nk <= 0 || nr <= 0 || nc <= 0 || nm <= 0) return -1;
  const int max_iterations = std::max(1, iterations);

  for (int iteration = 0; iteration < max_iterations; ++iteration) {
    for (int k = 0; k < nk; ++k) {
      card[k] = 0;
      changes[k] = 0.0f;
      for (int j = 0; j < nm; ++j) values[k][j] = 0.0f;
    }

    int changed = 0;
    for (int r = 0; r < nr; ++r) {
      for (int c = 0; c < nc; ++c) {
        int best = 0;
        float best_distance = std::numeric_limits<float>::max();
        for (int k = 0; k < nk; ++k) {
          float distance = 0.0f;
          for (int j = 0; j < nm; ++j) {
            const float difference = arr[j][r][c] - centers[k][j];
            distance += weights[j] * difference * difference;
          }
          dist[k][r][c] = distance;
          if (distance < best_distance) {
            best_distance = distance;
            best = k;
          }
        }
        if (ind[r][c] != best) ++changed;
        ind[r][c] = best;
        ++card[best];
        for (int j = 0; j < nm; ++j) values[best][j] += arr[j][r][c];
      }
    }

    for (int k = 0; k < nk; ++k) {
      if (card[k] == 0) continue;
      const float inverse_card = 1.0f / static_cast<float>(card[k]);
      for (int j = 0; j < nm; ++j) {
        const float next = values[k][j] * inverse_card;
        changes[k] += std::fabs(next - centers[k][j]);
        centers[k][j] = next;
      }
    }
    if (iteration == 0 || (iteration + 1) % 10 == 0 || changed == 0 || iteration + 1 == max_iterations)
      segmenter_logging::info("  K-means iteration %d/%d: %d pixel assignments changed.\n",
        iteration + 1, max_iterations, changed);
    if (changed == 0) break;
  }
  return 0;
}
