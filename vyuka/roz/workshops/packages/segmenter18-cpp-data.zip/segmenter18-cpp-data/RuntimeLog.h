// Runtime messages go to the console and to segmenter-run.log.
#ifndef SEGMENTER_RUNTIME_LOG_H
#define SEGMENTER_RUNTIME_LOG_H

#include <cstdarg>
#include <cstdio>
#include <fstream>
#include <vector>

namespace segmenter_logging {

inline std::ofstream log_file;

inline void start() {
  log_file.open("segmenter-run.log", std::ios::out | std::ios::trunc);
  if (!log_file)
    std::fprintf(stderr, "WARNING: cannot create segmenter-run.log.\n");
}

inline void write(FILE *stream, const char *format, va_list arguments) {
  va_list copy;
  va_copy(copy, arguments);
  const int size = std::vsnprintf(nullptr, 0, format, copy);
  va_end(copy);
  if (size < 0) return;
  std::vector<char> text(static_cast<std::size_t>(size) + 1);
  std::vsnprintf(text.data(), text.size(), format, arguments);
  std::fputs(text.data(), stream);
  std::fflush(stream);
  if (log_file) {
    log_file << text.data();
    log_file.flush();
  }
}

inline void info(const char *format, ...) {
  va_list arguments;
  va_start(arguments, format);
  write(stdout, format, arguments);
  va_end(arguments);
}

inline void error(const char *format, ...) {
  va_list arguments;
  va_start(arguments, format);
  write(stderr, format, arguments);
  va_end(arguments);
}

}  // namespace segmenter_logging

#endif
