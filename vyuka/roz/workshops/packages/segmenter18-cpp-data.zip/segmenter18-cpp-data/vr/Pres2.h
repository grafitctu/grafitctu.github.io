/* Portable PNG/JPEG presentation routines compatible with Segmenter.cpp. */

#ifndef SEGMENTER_PORT_PRES2_H
#define SEGMENTER_PORT_PRES2_H

#include "Global.h"
#include "PresInfo.h"
#include "../RuntimeLog.h"

#include <algorithm>
#include <cmath>
#include <vector>

namespace portable_vr {

int read_image(int key, const char *filename, std::vector<unsigned char> &pixels,
               int &width, int &height, int &channels);
int write_image(int key, const char *filename, const std::vector<unsigned char> &pixels,
                int width, int height, int channels);

inline unsigned char to_byte(long double value) {
  if (!std::isfinite(static_cast<double>(value))) return 0;
  value = std::max<long double>(0.0L, std::min<long double>(255.0L, value));
  return static_cast<unsigned char>(std::llround(value));
}

}  // namespace portable_vr

template <class TYPE>
int pres2(int key, TYPE ***ma, int *nc, int *nr, int *ncolour, int *nlevels,
          const char filename[], int aux = -1) {
  (void)aux;
  if (!ma || !nc || !nr || !ncolour || !filename) return IMGIO_WRONG_PARAMETER;

  if (pres_is_readkey(key) || !pres_is_writekey(key)) {
    std::vector<unsigned char> pixels;
    int width = 0, height = 0, channels = 0;
    const int status = portable_vr::read_image(key, filename, pixels, width, height, channels);
    if (status != IMGIO_OK) return status;

    const int requested_channels = std::max(1, *ncolour + 1);
    if (width != *nc || height != *nr) {
      segmenter_logging::error("ERROR: image '%s' has size %d x %d; XML expects %d x %d.\n",
        filename, width, height, *nc, *nr);
      return IMGIO_WRONG_PARAMETER;
    }

    for (int p = 0; p < requested_channels; ++p) {
      const int source_plane = (channels == 1) ? 0 : std::min(p, channels - 1);
      for (int r = 0; r < height; ++r) {
        for (int c = 0; c < width; ++c) {
          const std::size_t index =
              (static_cast<std::size_t>(r) * static_cast<std::size_t>(width) +
               static_cast<std::size_t>(c)) * static_cast<std::size_t>(channels) +
              static_cast<std::size_t>(source_plane);
          ma[p][r][c] = static_cast<TYPE>(pixels[index]);
        }
      }
    }
    *ncolour = requested_channels - 1;
    if (nlevels) *nlevels = 255;
    return IMGIO_OK;
  }

  const int width = *nc;
  const int height = *nr;
  const int channels = std::max(1, *ncolour + 1);
  if (width <= 0 || height <= 0) return IMGIO_WRONG_PARAMETER;

  std::vector<unsigned char> pixels(
      static_cast<std::size_t>(width) * static_cast<std::size_t>(height) *
      static_cast<std::size_t>(channels));
  for (int r = 0; r < height; ++r) {
    for (int c = 0; c < width; ++c) {
      for (int p = 0; p < channels; ++p) {
        const std::size_t index =
            (static_cast<std::size_t>(r) * static_cast<std::size_t>(width) +
             static_cast<std::size_t>(c)) * static_cast<std::size_t>(channels) +
            static_cast<std::size_t>(p);
        pixels[index] = portable_vr::to_byte(ma[p][r][c]);
      }
    }
  }
  return portable_vr::write_image(key, filename, pixels, width, height, channels);
}

template <class TYPE>
int pres2op(int key, TYPE ***a, int *nc, int *nr, int *ncolour, int *nlevels,
            const char filename[], int oneplane = -1, int aux = -1) {
  TYPE **single_plane = (oneplane < 0) ? nullptr : a[oneplane];
  TYPE ***planes = (oneplane < 0 || !ncolour || *ncolour != 0) ? a : &single_plane;
  return pres2(key, planes, nc, nr, ncolour, nlevels, filename, aux);
}

#endif  // SEGMENTER_PORT_PRES2_H
