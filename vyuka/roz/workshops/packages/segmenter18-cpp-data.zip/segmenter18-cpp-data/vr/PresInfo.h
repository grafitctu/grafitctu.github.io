/* Image-format keys retained from the VR presentation interface. */

#ifndef SEGMENTER_PORT_PRESINFO_H
#define SEGMENTER_PORT_PRESINFO_H

#include <cstdlib>

const int PRES_NO_KEY = 0;
const int PRES_DEFAULT_KEY = 10001;
const int PRES_READ_KEY = 9999;
const int PRES_WRITE_KEY = 9998;

const int PRES_READ_KEY_PNG = 301;
const int PRES_WRITE_KEY_PNG = 302;
const int PRES_READ_KEY_JPEG = 257;
const int PRES_WRITE_KEY_JPEG = 258;

/* PNM/PGM keys are kept as names for old parameter files.  The portable
 * implementation reads and writes them through stb only when a matching
 * extension is supplied; PNG/JPEG are the supported Mosaic path. */
const int PRES_READ_KEY_PPM_ASCII = 259;
const int PRES_WRITE_KEY_PPM_ASCII = 260;
const int PRES_READ_KEY_PPM_RAW = 255;
const int PRES_WRITE_KEY_PPM_RAW = 256;
const int PRES_READ_KEY_PGM_ASCII = 14;
const int PRES_WRITE_KEY_PGM_ASCII = 11;
const int PRES_READ_KEY_PGM_RAW = 9;
const int PRES_WRITE_KEY_PGM_RAW = 10;

inline bool pres_is_readkey(int key) {
  return key == PRES_READ_KEY_PNG || key == PRES_READ_KEY_JPEG ||
         key == PRES_READ_KEY_PPM_ASCII || key == PRES_READ_KEY_PPM_RAW ||
         key == PRES_READ_KEY_PGM_ASCII || key == PRES_READ_KEY_PGM_RAW ||
         key == PRES_READ_KEY;
}

inline bool pres_is_writekey(int key) {
  return key == PRES_WRITE_KEY_PNG || key == PRES_WRITE_KEY_JPEG ||
         key == PRES_WRITE_KEY_PPM_ASCII || key == PRES_WRITE_KEY_PPM_RAW ||
         key == PRES_WRITE_KEY_PGM_ASCII || key == PRES_WRITE_KEY_PGM_RAW ||
         key == PRES_WRITE_KEY;
}

inline int pres_get_writekey(int key) {
  switch (key) {
    case PRES_READ_KEY_PNG: return PRES_WRITE_KEY_PNG;
    case PRES_READ_KEY_JPEG: return PRES_WRITE_KEY_JPEG;
    case PRES_READ_KEY_PPM_ASCII: return PRES_WRITE_KEY_PPM_ASCII;
    case PRES_READ_KEY_PPM_RAW: return PRES_WRITE_KEY_PPM_RAW;
    case PRES_READ_KEY_PGM_ASCII: return PRES_WRITE_KEY_PGM_ASCII;
    case PRES_READ_KEY_PGM_RAW: return PRES_WRITE_KEY_PGM_RAW;
    default: return key;
  }
}

inline int pres_get_readkey(int key) {
  switch (key) {
    case PRES_WRITE_KEY_PNG: return PRES_READ_KEY_PNG;
    case PRES_WRITE_KEY_JPEG: return PRES_READ_KEY_JPEG;
    case PRES_WRITE_KEY_PPM_ASCII: return PRES_READ_KEY_PPM_ASCII;
    case PRES_WRITE_KEY_PPM_RAW: return PRES_READ_KEY_PPM_RAW;
    case PRES_WRITE_KEY_PGM_ASCII: return PRES_READ_KEY_PGM_ASCII;
    case PRES_WRITE_KEY_PGM_RAW: return PRES_READ_KEY_PGM_RAW;
    default: return key;
  }
}

#endif  // SEGMENTER_PORT_PRESINFO_H
