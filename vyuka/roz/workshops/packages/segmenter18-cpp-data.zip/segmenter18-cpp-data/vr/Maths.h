/* Math routines used by the original segmenter.  These replace the small
 * subset of VR/Maths that Segmenter.cpp actually calls. */

#ifndef SEGMENTER_PORT_MATHS_H
#define SEGMENTER_PORT_MATHS_H

#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

/* Jacobi eigensolver for a symmetric matrix with Numerical-Recipes-style
 * one-based indexing.  Segmenter.cpp deliberately keeps that historical
 * indexing convention for the PCA path. */
template <typename T>
inline int jacobi(T **a, int n, T d[], T **v, int *nrot) {
  if (!a || !d || !v || n < 1) return -1;
  std::vector<T> b(static_cast<std::size_t>(n + 1));
  std::vector<T> z(static_cast<std::size_t>(n + 1));

  for (int ip = 1; ip <= n; ++ip) {
    for (int iq = 1; iq <= n; ++iq) v[ip][iq] = static_cast<T>(0);
    v[ip][ip] = static_cast<T>(1);
    d[ip] = a[ip][ip];
    b[ip] = d[ip];
    z[ip] = static_cast<T>(0);
  }
  if (nrot) *nrot = 0;

  auto rotate_pair = [](T &g, T &h, T s, T tau) {
    const T old_g = g;
    const T old_h = h;
    g = old_g - s * (old_h + old_g * tau);
    h = old_h + s * (old_g - old_h * tau);
  };

  for (int iteration = 1; iteration <= 50; ++iteration) {
    T sm = static_cast<T>(0);
    for (int ip = 1; ip <= n - 1; ++ip)
      for (int iq = ip + 1; iq <= n; ++iq)
        sm += std::abs(a[ip][iq]);
    if (sm == static_cast<T>(0)) return 0;

    const T threshold = (iteration < 4)
        ? static_cast<T>(0.2) * sm / static_cast<T>(n * n)
        : static_cast<T>(0);

    for (int ip = 1; ip <= n - 1; ++ip) {
      for (int iq = ip + 1; iq <= n; ++iq) {
        const T g = static_cast<T>(100) * std::abs(a[ip][iq]);
        if (iteration > 4 &&
            std::abs(d[ip]) + g == std::abs(d[ip]) &&
            std::abs(d[iq]) + g == std::abs(d[iq])) {
          a[ip][iq] = static_cast<T>(0);
        } else if (std::abs(a[ip][iq]) > threshold) {
          T h = d[iq] - d[ip];
          T t;
          if (std::abs(h) + g == std::abs(h)) {
            t = a[ip][iq] / h;
          } else {
            const T theta = static_cast<T>(0.5) * h / a[ip][iq];
            t = static_cast<T>(1) /
                (std::abs(theta) + std::sqrt(static_cast<T>(1) + theta * theta));
            if (theta < static_cast<T>(0)) t = -t;
          }
          const T c = static_cast<T>(1) / std::sqrt(static_cast<T>(1) + t * t);
          const T s = t * c;
          const T tau = s / (static_cast<T>(1) + c);
          h = t * a[ip][iq];
          z[ip] -= h;
          z[iq] += h;
          d[ip] -= h;
          d[iq] += h;
          a[ip][iq] = static_cast<T>(0);

          for (int j = 1; j <= ip - 1; ++j) rotate_pair(a[j][ip], a[j][iq], s, tau);
          for (int j = ip + 1; j <= iq - 1; ++j) rotate_pair(a[ip][j], a[j][iq], s, tau);
          for (int j = iq + 1; j <= n; ++j) rotate_pair(a[ip][j], a[iq][j], s, tau);
          for (int j = 1; j <= n; ++j) rotate_pair(v[j][ip], v[j][iq], s, tau);
          if (nrot) ++(*nrot);
        }
      }
    }

    for (int ip = 1; ip <= n; ++ip) {
      b[ip] += z[ip];
      d[ip] = b[ip];
      z[ip] = static_cast<T>(0);
    }
  }
  return 1;  // did not converge within the historical 50-iteration limit
}

template <typename T>
inline void eigsrt(T d[], T **v, int n) {
  for (int i = 1; i < n; ++i) {
    int k = i;
    T p = d[i];
    for (int j = i + 1; j <= n; ++j) {
      if (d[j] >= p) {
        p = d[j];
        k = j;
      }
    }
    if (k != i) {
      std::swap(d[k], d[i]);
      for (int j = 1; j <= n; ++j) std::swap(v[j][i], v[j][k]);
    }
  }
}

inline float srgb_to_linear(float value) {
  value = std::max(0.0f, std::min(1.0f, value / 255.0f));
  return (value <= 0.04045f)
      ? value / 12.92f
      : std::pow((value + 0.055f) / 1.055f, 2.4f);
}

/* In-place RGB -> CIE Lab conversion used by the optional feature path. */
inline int imgRGB2Lab(float ***img, int nr, int nc, int actualPlane = 0) {
  if (!img || nr <= 0 || nc <= 0 || actualPlane < 0) return -1;
  const float epsilon = 216.0f / 24389.0f;
  const float kappa = 24389.0f / 27.0f;
  const float xn = 0.95047f;
  const float yn = 1.00000f;
  const float zn = 1.08883f;

  auto lab_f = [epsilon, kappa](float t) {
    return (t > epsilon) ? std::cbrt(t) : (kappa * t + 16.0f) / 116.0f;
  };

  for (int r = 0; r < nr; ++r) {
    for (int c = 0; c < nc; ++c) {
      const float red = srgb_to_linear(img[actualPlane][r][c]);
      const float green = srgb_to_linear(img[actualPlane + 1][r][c]);
      const float blue = srgb_to_linear(img[actualPlane + 2][r][c]);

      const float x = (0.4124564f * red + 0.3575761f * green + 0.1804375f * blue) / xn;
      const float y = (0.2126729f * red + 0.7151522f * green + 0.0721750f * blue) / yn;
      const float z = (0.0193339f * red + 0.1191920f * green + 0.9503041f * blue) / zn;
      const float fx = lab_f(x);
      const float fy = lab_f(y);
      const float fz = lab_f(z);

      img[actualPlane][r][c] = 116.0f * fy - 16.0f;
      img[actualPlane + 1][r][c] = 500.0f * (fx - fy);
      img[actualPlane + 2][r][c] = 200.0f * (fy - fz);
    }
  }
  return 0;
}

#endif  // SEGMENTER_PORT_MATHS_H
