/*
 * Portable replacement for the allocator part of VR.
 *
 * The original VR routines expose C-style arrays whose lower bounds are
 * chosen by the caller (for example, [-d..d] or [1..n]).  Keeping that
 * convention is important because Segmenter.cpp uses it directly.  The
 * implementation below owns ordinary C++ allocations and adds the required
 * pointer offsets; no binary VR library is needed.
 */

#ifndef SEGMENTER_PORT_TBALLOC_H
#define SEGMENTER_PORT_TBALLOC_H

#include <cstddef>

namespace vr_port_alloc_detail {

template <typename T>
inline T *allocate_1(int low, int high) {
  const int count = high - low + 1;
  if (count <= 0) return nullptr;
  const int prefix = (low > 0) ? low : 0;
  T *base = new T[static_cast<std::size_t>(count + prefix)]();
  return (low < 0) ? base - low : base;
}

template <typename T>
inline T *base_1(T *view, int low) {
  return (low < 0) ? view + low : view;
}

template <typename T>
inline T **allocate_rows(int low, int high) {
  const int count = high - low + 1;
  if (count <= 0) return nullptr;
  const int prefix = (low > 0) ? low : 0;
  T **base = new T *[static_cast<std::size_t>(count + prefix)]();
  return (low < 0) ? base - low : base;
}

template <typename T>
inline T **base_rows(T **view, int low) {
  return (low < 0) ? view + low : view;
}

template <typename T>
inline void free_rows(T **&view, int low, int high) {
  if (!view) return;
  for (int i = low; i <= high; ++i) {
    delete [] base_1(view[i], 0);
  }
  delete [] base_rows(view, low);
  view = nullptr;
}

template <typename T>
inline T ***allocate_planes(int low, int high) {
  const int count = high - low + 1;
  if (count <= 0) return nullptr;
  const int prefix = (low > 0) ? low : 0;
  T ***base = new T **[static_cast<std::size_t>(count + prefix)]();
  return (low < 0) ? base - low : base;
}

template <typename T>
inline T ***base_planes(T ***view, int low) {
  return (low < 0) ? view + low : view;
}

}  // namespace vr_port_alloc_detail

/* One-dimensional lower-bound array. */
template <typename T>
inline int vr_alloc(T *&view, int low, int high) {
  try {
    view = vr_port_alloc_detail::allocate_1<T>(low, high);
  } catch (...) {
    view = nullptr;
  }
  return view ? 1 : 0;
}

template <typename T>
inline int vr_free(T *&view, int low, int high) {
  (void)high;
  if (view) delete [] vr_port_alloc_detail::base_1(view, low);
  view = nullptr;
  return 1;
}

/* Two-dimensional lower-bound array. */
template <typename T>
inline int vr_alloc(T **&view, int row_low, int row_high,
                    int col_low, int col_high) {
  try {
    view = vr_port_alloc_detail::allocate_rows<T>(row_low, row_high);
    if (!view) return 0;
    for (int r = row_low; r <= row_high; ++r) {
      view[r] = vr_port_alloc_detail::allocate_1<T>(col_low, col_high);
      if (!view[r]) {
        for (int rr = row_low; rr < r; ++rr) {
          delete [] vr_port_alloc_detail::base_1(view[rr], col_low);
        }
        delete [] vr_port_alloc_detail::base_rows(view, row_low);
        view = nullptr;
        return 0;
      }
    }
  } catch (...) {
    view = nullptr;
    return 0;
  }
  return 1;
}

template <typename T>
inline int vr_free(T **&view, int row_low, int row_high,
                   int col_low, int col_high) {
  (void)col_high;
  if (!view) return 1;
  for (int r = row_low; r <= row_high; ++r) {
    if (view[r]) delete [] vr_port_alloc_detail::base_1(view[r], col_low);
  }
  delete [] vr_port_alloc_detail::base_rows(view, row_low);
  view = nullptr;
  return 1;
}

/* Three-dimensional lower-bound array. */
template <typename T>
inline int vr_alloc(T ***&view, int plane_low, int plane_high,
                    int row_low, int row_high, int col_low, int col_high) {
  try {
    view = vr_port_alloc_detail::allocate_planes<T>(plane_low, plane_high);
    if (!view) return 0;
    for (int p = plane_low; p <= plane_high; ++p) {
      view[p] = vr_port_alloc_detail::allocate_rows<T>(row_low, row_high);
      if (!view[p]) {
        for (int pp = plane_low; pp < p; ++pp) {
          for (int r = row_low; r <= row_high; ++r) {
            if (view[pp][r]) delete [] vr_port_alloc_detail::base_1(view[pp][r], col_low);
          }
          delete [] vr_port_alloc_detail::base_rows(view[pp], row_low);
        }
        delete [] vr_port_alloc_detail::base_planes(view, plane_low);
        view = nullptr;
        return 0;
      }
      for (int r = row_low; r <= row_high; ++r) {
        view[p][r] = vr_port_alloc_detail::allocate_1<T>(col_low, col_high);
        if (!view[p][r]) {
          for (int rr = row_low; rr < r; ++rr) {
            delete [] vr_port_alloc_detail::base_1(view[p][rr], col_low);
          }
          delete [] vr_port_alloc_detail::base_rows(view[p], row_low);
          for (int pp = plane_low; pp < p; ++pp) {
            for (int r2 = row_low; r2 <= row_high; ++r2) {
              if (view[pp][r2]) delete [] vr_port_alloc_detail::base_1(view[pp][r2], col_low);
            }
            delete [] vr_port_alloc_detail::base_rows(view[pp], row_low);
          }
          delete [] vr_port_alloc_detail::base_planes(view, plane_low);
          view = nullptr;
          return 0;
        }
      }
    }
  } catch (...) {
    view = nullptr;
    return 0;
  }
  return 1;
}

template <typename T>
inline int vr_free(T ***&view, int plane_low, int plane_high,
                   int row_low, int row_high, int col_low, int col_high) {
  (void)col_high;
  if (!view) return 1;
  for (int p = plane_low; p <= plane_high; ++p) {
    if (!view[p]) continue;
    for (int r = row_low; r <= row_high; ++r) {
      if (view[p][r]) delete [] vr_port_alloc_detail::base_1(view[p][r], col_low);
    }
    delete [] vr_port_alloc_detail::base_rows(view[p], row_low);
  }
  delete [] vr_port_alloc_detail::base_planes(view, plane_low);
  view = nullptr;
  return 1;
}

#endif  // SEGMENTER_PORT_TBALLOC_H
