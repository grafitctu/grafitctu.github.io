/*
 * Small, non-interactive reader for the parameter XML used by Mosaic's
 * segmenter.  It preserves the calls made by Segmenter.cpp while removing
 * the binary DyXML/VR dependency.  The supported format is the documented
 * <main>/<var>/<section>/<include> subset used by segmenter.xml.
 */

#ifndef SEGMENTER_PORT_DYXML_WRAPPER_H
#define SEGMENTER_PORT_DYXML_WRAPPER_H

#include "Global.h"

#include <cctype>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <vector>

#define DYXMLW_INIT_RUNS_DEFAULT 0
#define DYXMLW_NEXT_RUN_DEFAULT 0
#define DYXMLW_VALUE_CONFIG 0
#define DYXMLW_VALUE_REQUIRED 1
#define DYXMLW_VALUE_OPTIONAL 2
#define DYXMLW_SECTION_CONFIG 0
#define DYXMLW__NRUN__NAME "nrun"
#define DYXMLW_DEFAULT_PREFIX "run"
#define DYXMLW_DEFAULT_FROM 0
#define DYXMLW_DEFAULT_NRUN 1
#define DYXMLW_USE_RUN_AS_ARG 0
#define DYXMLW_OUTPUT_SYNCHRONIZED 0
#define DYXMLW_OUTPUT_INDEPENDENT 1

class DyXML_wrapper {
  struct Node {
    std::string tag;
    std::string name;
    std::string text;
    Node *parent = nullptr;
    std::vector<std::unique_ptr<Node>> children;
  };

  std::unique_ptr<Node> document;
  std::vector<Node *> scope_stack;
  std::deque<std::string> returned_strings;
  std::string source_name;
  std::string app_name;
  int state = IOPOK;
  int from = 0;
  int nrun = 1;
  int run = -1;
  int next_run_index = 0;

  static std::string trim(const std::string &value) {
    std::size_t first = 0;
    while (first < value.size() && std::isspace(static_cast<unsigned char>(value[first]))) ++first;
    std::size_t last = value.size();
    while (last > first && std::isspace(static_cast<unsigned char>(value[last - 1]))) --last;
    return value.substr(first, last - first);
  }

  static std::string unescape(std::string value) {
    const std::pair<const char *, const char *> replacements[] = {
      {"&quot;", "\""}, {"&apos;", "'"}, {"&lt;", "<"},
      {"&gt;", ">"}, {"&amp;", "&"}
    };
    for (const auto &replacement : replacements) {
      std::size_t pos = 0;
      while ((pos = value.find(replacement.first, pos)) != std::string::npos) {
        value.replace(pos, std::string(replacement.first).size(), replacement.second);
        pos += std::string(replacement.second).size();
      }
    }
    return value;
  }

  static std::string value_text(const Node *node) {
    if (!node) return std::string();
    std::string value = trim(unescape(node->text));
    if (value.size() >= 2 &&
        ((value.front() == '"' && value.back() == '"') ||
         (value.front() == '\'' && value.back() == '\''))) {
      value = value.substr(1, value.size() - 2);
    }
    return trim(value);
  }

  static std::string attribute(const std::string &inside, const std::string &wanted) {
    std::size_t pos = 0;
    while (pos < inside.size() && !std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
    while (pos < inside.size()) {
      while (pos < inside.size() && std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
      if (pos >= inside.size() || inside[pos] == '/') break;
      const std::size_t key_start = pos;
      while (pos < inside.size() && inside[pos] != '=' &&
             !std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
      const std::string key = inside.substr(key_start, pos - key_start);
      while (pos < inside.size() && std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
      if (pos >= inside.size() || inside[pos] != '=') break;
      ++pos;
      while (pos < inside.size() && std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
      if (pos >= inside.size()) break;
      const char quote = inside[pos];
      if (quote == '\'' || quote == '"') {
        ++pos;
        const std::size_t value_start = pos;
        while (pos < inside.size() && inside[pos] != quote) ++pos;
        const std::string value = inside.substr(value_start, pos - value_start);
        if (key == wanted) return unescape(value);
        if (pos < inside.size()) ++pos;
      } else {
        const std::size_t value_start = pos;
        while (pos < inside.size() && !std::isspace(static_cast<unsigned char>(inside[pos]))) ++pos;
        if (key == wanted) return unescape(inside.substr(value_start, pos - value_start));
      }
    }
    return std::string();
  }

  bool parse(const std::string &xml) {
    document.reset();
    std::vector<Node *> stack;
    std::size_t pos = 0;
    while (pos < xml.size()) {
      if (xml.compare(pos, 4, "<!--") == 0) {
        const std::size_t end = xml.find("-->", pos + 4);
        if (end == std::string::npos) return false;
        pos = end + 3;
        continue;
      }
      if (xml.compare(pos, 9, "<![CDATA[") == 0) {
        const std::size_t end = xml.find("]]>", pos + 9);
        if (end == std::string::npos || stack.empty()) return false;
        stack.back()->text += xml.substr(pos + 9, end - pos - 9);
        pos = end + 3;
        continue;
      }
      const std::size_t open = xml.find('<', pos);
      if (open == std::string::npos) {
        if (!stack.empty()) stack.back()->text += xml.substr(pos);
        break;
      }
      if (open > pos && !stack.empty()) stack.back()->text += xml.substr(pos, open - pos);
      if (xml.compare(open, 4, "<!--") == 0) {
        const std::size_t end = xml.find("-->", open + 4);
        if (end == std::string::npos) return false;
        pos = end + 3;
        continue;
      }
      if (xml.compare(open, 9, "<![CDATA[") == 0) {
        const std::size_t end = xml.find("]]>", open + 9);
        if (end == std::string::npos || stack.empty()) return false;
        stack.back()->text += xml.substr(open + 9, end - open - 9);
        pos = end + 3;
        continue;
      }
      const std::size_t close = xml.find('>', open + 1);
      if (close == std::string::npos) return false;
      std::string inside = trim(xml.substr(open + 1, close - open - 1));
      pos = close + 1;
      if (inside.empty() || inside.front() == '?' || inside.front() == '!') continue;
      if (inside.front() == '/') {
        if (stack.empty()) return false;
        stack.pop_back();
        continue;
      }

      bool self_closing = false;
      if (!inside.empty() && inside.back() == '/') {
        self_closing = true;
        inside = trim(inside.substr(0, inside.size() - 1));
      }
      std::size_t split = 0;
      while (split < inside.size() && !std::isspace(static_cast<unsigned char>(inside[split]))) ++split;
      auto node = std::make_unique<Node>();
      node->tag = inside.substr(0, split);
      node->name = attribute(inside, "name");
      node->parent = stack.empty() ? nullptr : stack.back();
      Node *raw = node.get();
      if (stack.empty()) {
        if (document) return false;
        document = std::move(node);
      } else {
        stack.back()->children.push_back(std::move(node));
      }
      if (!self_closing) stack.push_back(raw);
    }
    return document != nullptr;
  }

  bool load_file(const char *filename) {
    source_name = filename ? filename : std::string();
    std::ifstream input(source_name, std::ios::binary);
    if (!input) {
      state = IMGIO_FILE_NOT_OPENED;
      std::cerr << "Segmenter: cannot open parameter file '" << source_name << "'.\n";
      return false;
    }
    std::ostringstream contents;
    contents << input.rdbuf();
    if (!parse(contents.str())) {
      state = IMGIO_FILE_CONTENTS_PROBLEM;
      std::cerr << "Segmenter: invalid parameter XML in '" << source_name << "'.\n";
      return false;
    }
    state = IOPOK;
    return true;
  }

  Node *named_section(Node *parent, const std::string &wanted) const {
    if (!parent) return nullptr;
    for (const auto &child : parent->children) {
      if (child->tag == "section" && child->name == wanted) return child.get();
    }
    return nullptr;
  }

  Node *root_named_section(const std::string &wanted) const {
    return named_section(document.get(), wanted);
  }

  Node *section_from(Node *scope, const std::string &wanted,
                     std::unordered_set<const Node *> &visited) const {
    if (!scope || visited.count(scope)) return nullptr;
    visited.insert(scope);
    if (Node *direct = named_section(scope, wanted)) return direct;
    for (const auto &child : scope->children) {
      if (child->tag != "include") continue;
      const std::string include_name = value_text(child.get());
      if (Node *included = root_named_section(include_name)) {
        if (Node *found = section_from(included, wanted, visited)) return found;
      }
    }
    return nullptr;
  }

  bool value_from(Node *scope, const std::string &wanted, std::string &value,
                  std::unordered_set<const Node *> &visited) const {
    if (!scope || visited.count(scope)) return false;
    visited.insert(scope);
    for (const auto &child : scope->children) {
      if (child->tag == "var" && child->name == wanted) {
        value = value_text(child.get());
        return true;
      }
    }
    for (const auto &child : scope->children) {
      if (child->tag != "include") continue;
      const std::string include_name = value_text(child.get());
      if (Node *included = root_named_section(include_name)) {
        if (value_from(included, wanted, value, visited)) return true;
      }
    }
    return false;
  }

  bool current_value(const char *name, std::string &value) const {
    if (!name) return false;
    Node *scope = scope_stack.empty() ? document.get() : scope_stack.back();
    std::unordered_set<const Node *> visited;
    return value_from(scope, name, value, visited);
  }

  template <typename T>
  static bool parse_scalar(const std::string &text, T &value) {
    std::istringstream stream(text);
    stream >> value;
    return !stream.fail();
  }

  static bool parse_scalar(const std::string &text, char &value) {
    if (text.size() == 1) {
      value = text.front();
      return true;
    }
    std::istringstream stream(text);
    int number = 0;
    stream >> number;
    if (stream.fail()) return false;
    value = static_cast<char>(number);
    return true;
  }

public:
  DyXML_wrapper(const char *app = nullptr, int _state = IOPOK)
      : app_name(app ? app : "Segmenter"), state(_state) {}

  DyXML_wrapper(const char *filename, const char *app, int _state = IOPOK)
      : app_name(app ? app : "Segmenter"), state(_state) {
    load_file(filename);
  }

  DyXML_wrapper(int argc, char *argv[], const char *app = nullptr, int _state = IOPOK)
      : app_name(app ? app : "Segmenter"), state(_state) {
    const char *filename = (argc > 1 && argv && argv[1]) ? argv[1] : "segmenter.xml";
    load_file(filename);
  }

  ~DyXML_wrapper() = default;

  int init_runs(int = DYXMLW_INIT_RUNS_DEFAULT,
                const char *nrun_name = DYXMLW__NRUN__NAME,
                const char *prefix_name = DYXMLW_DEFAULT_PREFIX,
                int default_from = DYXMLW_DEFAULT_FROM,
                int default_runs = DYXMLW_DEFAULT_NRUN,
                const char * = nullptr) {
    from = default_from;
    nrun = default_runs;
    next_run_index = from;
    run = -1;

    std::string value;
    std::unordered_set<const Node *> visited;
    if (value_from(document.get(), nrun_name, value, visited)) {
      parse_scalar(value, nrun);
    }
    visited.clear();
    if (value_from(document.get(), "from", value, visited)) {
      parse_scalar(value, from);
      next_run_index = from;
    }
    prefix = prefix_name ? prefix_name : DYXMLW_DEFAULT_PREFIX;
    visited.clear();
    if (value_from(document.get(), "prefix", value, visited)) prefix = value;
    return nrun;
  }

  int next_run(int = DYXMLW_NEXT_RUN_DEFAULT) {
    if (!document || next_run_index >= from + nrun) return 0;
    const std::string section_name = prefix + "_!" + std::to_string(next_run_index);
    Node *selected = root_named_section(section_name);
    if (!selected) {
      std::cerr << "Segmenter: missing run section '" << section_name << "'.\n";
      return 0;
    }
    run = next_run_index++;
    scope_stack.clear();
    scope_stack.push_back(selected);
    returned_strings.clear();
    return 1;
  }

  int set_run(int = DYXMLW_NEXT_RUN_DEFAULT, int = DYXMLW_USE_RUN_AS_ARG) {
    return (run >= from) ? 1 : 0;
  }

  int select(const char *section, int = DYXMLW_VALUE_CONFIG,
             int = DYXMLW_SECTION_CONFIG, const char * = nullptr,
             int = DYXMLW_USE_RUN_AS_ARG) {
    if (!section) return 0;
    Node *scope = scope_stack.empty() ? document.get() : scope_stack.back();
    std::unordered_set<const Node *> visited;
    Node *selected = section_from(scope, section, visited);
    if (!selected) return 0;
    scope_stack.push_back(selected);
    return 1;
  }

  int select_i(const char *section, int, int req = DYXMLW_VALUE_CONFIG,
               int add = DYXMLW_SECTION_CONFIG, const char *prompt = nullptr,
               int arg = DYXMLW_USE_RUN_AS_ARG) {
    return select(section, req, add, prompt, arg);
  }

  int back() {
    if (scope_stack.size() > 1) scope_stack.pop_back();
    return static_cast<int>(scope_stack.size());
  }

  int top() {
    if (scope_stack.empty()) return 0;
    Node *root_scope = scope_stack.front();
    scope_stack.clear();
    scope_stack.push_back(root_scope);
    return 1;
  }

  int get_level() const { return static_cast<int>(scope_stack.size()); }
  int get_run() const { return run; }
  int get_nrun() const { return nrun; }
  int get_from() const { return from; }
  int get_state() const { return state; }

  template <typename T>
  int get_val(T &value, const char *name, int required = DYXMLW_VALUE_CONFIG,
              T default_value = T(), const char * = nullptr,
              int = DYXMLW_USE_RUN_AS_ARG) {
    std::string text;
    if (!current_value(name, text)) {
      value = default_value;
      if (required == DYXMLW_VALUE_REQUIRED) {
        std::cerr << "Segmenter: required parameter '" << (name ? name : "") << "' is missing.\n";
        return -1;
      }
      return 0;
    }
    if (!parse_scalar(text, value)) {
      std::cerr << "Segmenter: invalid value '" << text << "' for parameter '"
                << (name ? name : "") << "'.\n";
      value = default_value;
      return -1;
    }
    return 0;
  }

  template <typename T>
  int get_val_req(T &value, const char *name, const char *prompt = nullptr,
                  int arg = DYXMLW_USE_RUN_AS_ARG) {
    return get_val(value, name, DYXMLW_VALUE_REQUIRED, T(), prompt, arg);
  }

  template <typename T>
  int get_val_opt(T &value, const char *name, T default_value = T(),
                  const char *prompt = nullptr, int arg = DYXMLW_USE_RUN_AS_ARG) {
    return get_val(value, name, DYXMLW_VALUE_OPTIONAL, default_value, prompt, arg);
  }

  int get_str(const char *&value, const char *name, int required = DYXMLW_VALUE_CONFIG,
              const char *default_value = nullptr, const char * = nullptr,
              int = DYXMLW_USE_RUN_AS_ARG) {
    std::string text;
    if (!current_value(name, text)) {
      if (!default_value && required == DYXMLW_VALUE_REQUIRED) {
        value = nullptr;
        std::cerr << "Segmenter: required parameter '" << (name ? name : "") << "' is missing.\n";
        return -1;
      }
      if (!default_value) {
        value = nullptr;
        return 0;
      }
      text = default_value;
    }
    returned_strings.push_back(text);
    value = returned_strings.back().c_str();
    return 0;
  }

  int get_str_req(const char *&value, const char *name, const char *prompt = nullptr,
                  int arg = DYXMLW_USE_RUN_AS_ARG) {
    return get_str(value, name, DYXMLW_VALUE_REQUIRED, nullptr, prompt, arg);
  }

  int get_str_opt(const char *&value, const char *name, const char *default_value = nullptr,
                  const char *prompt = nullptr, int arg = DYXMLW_USE_RUN_AS_ARG) {
    return get_str(value, name, DYXMLW_VALUE_OPTIONAL, default_value, prompt, arg);
  }

private:
  std::string prefix;
};

#endif  // SEGMENTER_PORT_DYXML_WRAPPER_H
