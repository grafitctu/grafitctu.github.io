/* K-means interface preserved from the VR-based segmenter. */

#ifndef SEGMENTER_PORT_KMEANS_H
#define SEGMENTER_PORT_KMEANS_H

class KMeans {
 public:
  float ***dist;
  float *changes;
  float **centers;
  float **values;
  float *weights;
  int *card;

  int nk, nr, nc, nm;
  float ***arr;
  int **ind;

  KMeans(int nk, int nr, int nc, int nm);
  ~KMeans();

  int initialize(int norm);
  int compute(int np);
};

#endif  // SEGMENTER_PORT_KMEANS_H
