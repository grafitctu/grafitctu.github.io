/* Small set of VR/Pres constants used by the portable segmenter. */

#ifndef SEGMENTER_PORT_GLOBAL_H
#define SEGMENTER_PORT_GLOBAL_H

#define IMGIO_OK                      0
#define IMGIO_FILE_NOT_OPENED        -1
#define IMGIO_NOT_A_PNG              -2
#define IMGIO_ALLOCATION_PROBLEM     -3
#define IMGIO_FILE_READ_PROBLEM      -4
#define IMGIO_FILE_WRITE_PROBLEM     -5
#define IMGIO_FILE_CONTENTS_PROBLEM  -6
#define IMGIO_WRONG_PARAMETER       -7
#define IMGIO_NOT_IMPLEMENTED       -10

#define IOPFILEAPPEND    1
#define IOPFILEOVERWRITE 2
#define IOPOK             255
#define IOPFALSE          0
#define IOPNOSECTION      100

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#endif  // SEGMENTER_PORT_GLOBAL_H
