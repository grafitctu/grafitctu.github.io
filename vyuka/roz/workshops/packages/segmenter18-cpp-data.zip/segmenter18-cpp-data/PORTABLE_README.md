# Portable CVUT segmenter

This directory is a source-based replacement for the VR-library part of the
Mosaic/CVUT segmenter.  The segmentation pipeline in `Segmenter.cpp` is kept
from the public CVUT segmenter package and remains the main file to modify for
a student project.

## Provenance

The historical course package followed Mosaic segmenter 1.4 and linked a
system-specific, precompiled `vr/libvr.a`.  The installation instructions are
preserved on the Mosaic page:

<https://mosaic.utia.cas.cz/cvut2016_zimni.html>

The original segmenter source package is available in the NI-ROZ course
archive.  The historical binary library is deliberately not used here and is
not redistributed by this port.

## What changed

`Segmenter.cpp` still owns the original processing sequence:

1. load the image,
2. compute and blur features,
3. optionally apply PCA/KL reduction,
4. cluster with K-means,
5. create a thematic map and post-process regions,
6. save the segmentation and optional borders.

The new `PortableVR.cpp` and headers under `vr/` replace the library boundary
with source code for the subset used by this program:

- lower-bound multidimensional allocation (`TBAlloc.h`),
- PNG/JPEG input and output (`Pres2.h`, `PortableVR.cpp`, stb headers),
- RGB to CIE Lab conversion and symmetric Jacobi/PCA routines (`Maths.h`),
- K-means clustering (`KMeans.h`, `PortableVR.cpp`),
- the parameter XML subset used by `segmenter.xml` (`DyXML_wrapper.h`).

This is a compatible implementation, not a claim of bit-for-bit equivalence
with the closed historical VR library.  Before using it for a scored Mosaic
submission, compare output dimensions, label conventions, and benchmark
scores with the historical binary on the same input.

## Build and run

The makefile expects a C++17 compiler and no external VR installation:

```text
make
./segmenter
# Or select the configuration directly, without a prompt:
./segmenter segmenter.xml
```

On Windows with MinGW, the same command can be run from the corresponding
shell after installing `make` and `g++`.

### Choose a dataset / Výběr datové sady

Run `./segmenter` (Linux) or `.\segmenter.exe` (Windows) without an argument.
The program lists XML files in the current directory and asks for a number or
an XML filename/path. Pressing Enter alone does not start a default dataset;
an unknown filename or number asks again. Enter `q` to cancel.

The supplied configurations are:

- `segmenter-smoke.xml`: one Mosaic image, a short local check;
- `segmenter.xml`: the five supplied Mosaic images;
- `bsds.xml`: the 16 supplied BSDS photographs;
- `colour_large.xml`: the full 80-image Mosaic configuration. The small source
  package only includes five Mosaic images; install the complete dataset before
  using this configuration for all 80 images.

The BSDS XML preserves the original JPEG dimensions: `138078.jpg` and
`157036.jpg` are 482 columns wide, while the other supplied photographs are 481.

For another data package, enter the path to its XML. Relative input and output
paths are resolved from the **selected XML's directory**, not from the folder
where the executable happens to be. The program prints that directory and all
saved output paths. `segmenter-run.log` remains in the directory where the
program was started.

An XML argument skips the interactive question, for example:

```powershell
.\segmenter.exe bsds.xml
.\segmenter.exe "D:\datasets\another package\data.xml"
```

Bez argumentu se segmenter zeptá na XML datové sady. Zadejte číslo z nabídky,
název souboru (např. `bsds.xml`) nebo cestu k XML jiného balíku. Cesty k obrázkům
i výstupům se počítají od složky tohoto XML. Konfigurace `colour_large.xml`
vyžaduje celou 80obrázkovou množinu; tento malý balík obsahuje jen pět mozaik.
Příkaz `.\segmenter.exe bsds.xml` spustí BSDS rovnou, bez dotazu.

### Visual Studio Code on Windows

The project contains a `.vscode` configuration for the Visual Studio MSVC
toolchain. The build script uses `vswhere` to locate an installed C++ workload,
including Community and Build Tools editions. Open this directory as a folder
in VS Code, then use:

- `Build segmenter (MSVC)` to compile `main.cpp`, `Segmenter.cpp`, and
  `PortableVR.cpp`;
- `Run C++ segmenter (choose XML)` to choose the dataset interactively, either
  as a task or as the debugger configuration used by `F5`;
- `Run C++ smoke test` to run the small local test on `data/tm1_1_1.png`;

F5 runs in the **Terminal**, because the program needs keyboard input. At
`XML>` enter a number or a filename and press Enter. The **Debug Console** is
not an input terminal. The program prints the selected parameter file, loaded
image dimensions, processing stages, K-means progress, and full
paths of the saved files. The last line says `SUCCESS` only when all configured
images have been processed and saved. Failed image reads/writes stop the run
with a nonzero exit code.

The same messages are saved to `segmenter-run.log` in the launch directory;
each run replaces this log. The smoke test writes `smoke/seg.png` (raw class
labels), `smoke/overlay.png` (input image with segmentation borders), and
`smoke/edges.png` (borders). Open the overlay to inspect the result: raw labels
1, 2, 3 are nearly black when displayed as ordinary grayscale intensities.

Při F5 se používá záložka **Terminal**. Na řádku `XML>` zadejte číslo nebo název
XML a stiskněte Enter. Výpis potvrdí načtení obrázků, průběh segmentace i uložení
výsledků. Stejný výpis zůstane v souboru `segmenter-run.log`. Pro rychlou kontrolu
vyberte `segmenter-smoke.xml` a otevřete `smoke/overlay.png`.

The smoke test is only a local sanity check; the
Mosaic submission still uses the full benchmark XML and the required output
package.

Input and output names may omit the extension.  The portable image layer then
tries or adds `.png` (and also accepts JPEG).  It preserves segmentation
labels as direct 8-bit values, so a class map with labels 1, 2, ... is not
silently rescaled to the full grayscale range.

## Scope of the XML reader

The reader supports the Mosaic segmenter configuration form used here:
`main`, `var`, `section`, `include`, `nrun`, `from`, `prefix`, run selection,
nested sections, required/optional scalar values, and strings.  It is
intentionally non-interactive: missing required values are reported instead
of opening the old VR prompt interface. The separate file-selection prompt
lives in `ConfigurationInput.h` and does not change the feature function.

## Verification note

On Windows, after building, run `./tests/check-startup.ps1` in PowerShell 7 to
check interactive selection, direct arguments, paths with spaces/diacritics,
cancellation and error handling. Add `-FullDatasets` to process all five supplied
Mosaic images and all 16 BSDS images. These tests do not compare benchmark scores.

The source package can be inspected without the old binary.  A numerical
comparison against the historical `libvr.a` still requires a C++ toolchain and
the matching historical test data; keep that comparison separate from this
source port and record any score differences.
