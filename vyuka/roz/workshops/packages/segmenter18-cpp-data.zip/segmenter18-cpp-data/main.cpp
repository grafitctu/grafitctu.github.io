
/* CVUT 2023 - main file */
/* segmenter v1.6 */

#include "Segmenter.h"
#include "DyXML_wrapper.h"
#include <stdlib.h>
#include <stdio.h>
#include <chrono>
#include <exception>
#include <filesystem>
#include "ConfigurationInput.h"
#include "RuntimeLog.h"


// Derive your own segmenter class
class MySegmenter : public Segmenter {
//  virtual int features(DyXML_wrapper &par);
//  virtual int clustering(DyXML_wrapper &par);
//  virtual int postprocessing(DyXML_wrapper &par);
};


// Override your function below
// explore parent (Segmenter) function before

/*int MySegmenter::features(DyXML_wrapper &par) {

// load parameters
// par. ...

// feature vector size
// nfeat=...

// allocate features array
  vr_alloc(feat,0,nfeat-1,0,nr-1,0,nc-1);

// compute the features
// ...
// for monospectral features do not convert colour image into grey levels
// compute features on every spectral plane instead
// (KL-transformation can be used for decorrelation)

  return 0;
}*/

/*int MySegmenter::clustering(DyXML_wrapper &par) {

// load parameters
// par. ...

// allocate probability maps array and initialize
  vr_alloc(probs,0,nclust-1,0,nr-1,0,nc-1);

// compute probability maps
// ...

  return 0;
}*/

/*int MySegmenter::postprocessing(DyXML_wrapper &par) {

// obtain thematic map directly
  thematic_map(par);
// or call the base class function
  Segmenter::postprocessing(par);

// load parameters
// par. ...

// do some postprocessing
// ...

  return 0;
}*/


// Main function - maintains processing loop and parameters
int main(int argc, char* argv[]) {
  segmenter_startup::ConsoleEncoding console_encoding;
  segmenter_logging::start();
  try {
    const auto log_path = std::filesystem::absolute("segmenter-run.log");
    segmenter_logging::info("C++ segmenter\nStarted in: %s\n",
      std::filesystem::current_path().u8string().c_str());
    std::filesystem::path config;
    const auto selection = segmenter_startup::select_configuration(argc, argv, config);
    if (selection != segmenter_startup::Selection::selected)
      return selection == segmenter_startup::Selection::cancelled ? 0 : 1;

    // Dataset packages carry their own relative input and output paths.
    std::filesystem::current_path(config.parent_path());
    segmenter_logging::info("\nParameters: %s\nData/output base directory: %s\nRuntime log: %s\n",
      config.u8string().c_str(),
      std::filesystem::current_path().u8string().c_str(),
      log_path.u8string().c_str());
    const auto started = std::chrono::steady_clock::now();

    const std::string config_name = config.filename().string();
    DyXML_wrapper par(config_name.c_str(),"Segmenter");  // load the selected XML
    if (par.get_state() != IOPOK) {
      segmenter_logging::error("ERROR: parameter file could not be loaded. No images were processed.\n");
      return 1;
    }

    par.init_runs();                           // initialize default parameters
    segmenter_logging::info("Configured runs: %d\n", par.get_nrun());
    int completed = 0;
    while (par.next_run()) {                   // main loop over all computation runs
      segmenter_logging::info("\nRun %d/%d (XML section run_!%d)\n",
        completed + 1, par.get_nrun(), par.get_run());
      MySegmenter seg;                         // instance of the overriden class
      if (seg.run(par) != 0) {
        segmenter_logging::error("ERROR: run failed. Successfully completed images: %d.\n", completed);
        return 1;
      }
      ++completed;
    }
    if (completed == 0 || completed != par.get_nrun()) {
      segmenter_logging::error("ERROR: completed %d of %d configured runs. Check the run sections in the XML.\n",
        completed, par.get_nrun());
      return 1;
    }
    const double seconds = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - started).count();
    segmenter_logging::info("\nSUCCESS: processed and saved %d image(s) in %.2f s.\n", completed, seconds);
  } catch (const std::exception &error) {
    segmenter_logging::error("ERROR: %s\n", error.what());
    return 1;
  }
  return 0;
}
