// Reconstruction of static CS/CA. See PROTOCOL.md for definitions and replay evidence.
// Never interpret uploaded XML or derive a reference path from an upload.
import {inflateSync, inflateRawSync, deflateSync} from "node:zlib";
import {Buffer} from "node:buffer";
export const PROTOCOL="static-semantic-075-maxoverlap-v1";
export const METRICS=["cs","ca","os","us","ari","vi"];
export const METRIC_UNITS={cs:"fraction",ca:"fraction",os:"fraction",us:"fraction",ari:"index",vi:"bits"};
export const MAX_BODY=32*1024**2, MAX_FILE=2*1024**2;
export class InputError extends Error { constructor(code,detail=""){super(code);this.code=code;this.detail=String(detail).slice(0,180);} }
const bad=(code,detail)=>{throw new InputError(code,detail)};
export async function hash(b){return Buffer.from(await crypto.subtle.digest("SHA-256",b)).toString("hex")}
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
export function crc32(b){let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return (c^0xffffffff)>>>0}
const safeName=n=>{if(!/^[A-Za-z0-9_][A-Za-z0-9_.-]{0,99}$/.test(n))bad("unsafe_name",n);return n};
export function inventory(names,ds){
 const expected=new Set(["data.xml",...ds.cases.map(c=>c.seg)]);
 const inputs=new Set(ds.cases.map(c=>c.tm));
 if(new Set(names.map(n=>n.toLowerCase())).size!==names.length)bad("duplicate");
 const missing=ds.cases.map(c=>c.seg).filter(n=>!names.includes(n)),extra=names.filter(n=>!expected.has(n)&&!inputs.has(n));
 if(extra.length)bad("inventory",JSON.stringify({extra:extra.slice(0,3)}));
 if(missing.length===ds.cases.length)bad("no_segments");
 return {missing,ignored:names.filter(n=>inputs.has(n)),xml_provided:names.includes("data.xml")};
}
function unzip(raw,ds){
 const b=Buffer.from(raw.buffer,raw.byteOffset,raw.byteLength);
 if(b.length<22)bad("zip");
 let e=-1;
 for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--)if(b.readUInt32LE(i)===0x06054b50&&i+22+b.readUInt16LE(i+20)===b.length){e=i;break}
 if(e<0)bad("zip");
 const n=b.readUInt16LE(e+10),size=b.readUInt32LE(e+12),off=b.readUInt32LE(e+16);
 if(b.readUInt32LE(e+4)!==0||b.readUInt16LE(e+8)!==n||off+size!==e)bad("zip");
 if(n>128||size>131072)bad("limit");
 let p=off,total=0;const entries=[];
 for(let i=0;i<n;i++){
  if(p+46>e||b.readUInt32LE(p)!==0x02014b50)bad("zip");
  const flags=b.readUInt16LE(p+8),method=b.readUInt16LE(p+10),crc=b.readUInt32LE(p+16),compressed=b.readUInt32LE(p+20),len=b.readUInt32LE(p+24);
  const nl=b.readUInt16LE(p+28),xl=b.readUInt16LE(p+30),cl=b.readUInt16LE(p+32),local=b.readUInt32LE(p+42);
  if(p+46+nl+xl+cl>e)bad("zip");
  const name=safeName(b.subarray(p+46,p+46+nl).toString("utf8"));
  if((flags&~0x808)!==0||![0,8].includes(method)||len>MAX_FILE||compressed>MAX_FILE)bad("limit",name);
  total+=len;if(total>96*1024**2)bad("limit");
  if(local+30>off||b.readUInt32LE(local)!==0x04034b50)bad("zip",name);
  const lnl=b.readUInt16LE(local+26),lxl=b.readUInt16LE(local+28),start=local+30+lnl+lxl;
  if(b.readUInt16LE(local+6)!==flags||b.readUInt16LE(local+8)!==method||start+compressed>off||
      b.subarray(local+30,local+30+lnl).toString("utf8")!==name)bad("zip",name);
  entries.push({name,crc,len,compressed,start,local,method});p+=46+nl+xl+cl;
 }
 if(p!==e)bad("zip");const manifest=inventory(entries.map(v=>v.name),ds);
 const sorted=[...entries].sort((a,b)=>a.local-b.local);
 for(let i=1;i<sorted.length;i++)if(sorted[i].local<sorted[i-1].start+sorted[i-1].compressed)bad("zip");
 const lookup=new Map(entries.map(v=>[v.name,v]));
 return Object.assign(name=>{
  const v=lookup.get(name);if(!v)return undefined;
  const src=b.subarray(v.start,v.start+v.compressed);let data;
  try{data=v.method===0?src:inflateRawSync(src,{maxOutputLength:MAX_FILE+65536});}catch{bad("zip",name)}
  if(data.length!==v.len||crc32(data)!==v.crc)bad("zip",name);
  return data;
 },{manifest});
}
function loose(raw,ds){
 const b=Buffer.from(raw);if(b.length<4)bad("inventory");const n=b.readUInt32BE(0);
 if(n<1||n>16384||n+4>b.length)bad("inventory");
 let header;try{header=JSON.parse(b.subarray(4,n+4).toString("utf8"))}catch{bad("inventory")}
 if(!Array.isArray(header)||header.length>128)bad("inventory");
 let at=n+4;const files=new Map(),names=[];
 for(const row of header){
  if(!Array.isArray(row)||row.length!==2)bad("inventory");
  const [name,len]=row;if(typeof name!=="string"||!Number.isInteger(len)||len<0||len>MAX_FILE)bad("limit");
  safeName(name);names.push(name);files.set(name,b.subarray(at,at+len));at+=len;
 }
 if(at!==b.length)bad("inventory");const manifest=inventory(names,ds);return Object.assign(n=>files.get(n),{manifest});
}
export function readUpload(raw,ds,type){
 if(raw.length>MAX_BODY)bad("limit");
 if(type==="application/zip")return unzip(raw,ds);
 if(type==="application/x-mosaic-files")return loose(raw,ds);
 bad("format");
}
function paeth(a,b,c){const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c}
export function pngLabels(raw,width,height,name="PNG"){
 const b=Buffer.from(raw);
 if(b.length>MAX_FILE||b.length<45||b.subarray(0,8).toString("hex")!=="89504e470d0a1a0a")bad("format",name);
 let p=8,depth=0,color=-1,interlace=0,seenHeader=false,ended=false,closedIdat=false,seenIdat=false;
 const chunks=[];
 while(p+12<=b.length){
  const n=b.readUInt32BE(p),type=b.toString("ascii",p+4,p+8);
  if(n>b.length-p-12||crc32(b.subarray(p+4,p+8+n))!==b.readUInt32BE(p+8+n))bad("corrupt",name);
  const data=b.subarray(p+8,p+8+n);
  if(!seenHeader&&type!=="IHDR")bad("corrupt",name);
  if(type==="IHDR"){
   if(seenHeader||n!==13)bad("corrupt",name);
   seenHeader=true;
   if(data.readUInt32BE(0)!==width||data.readUInt32BE(4)!==height)bad("dimensions",name);
   depth=data[8];color=data[9];interlace=data[12];
   if(![0,3].includes(color)||![1,2,4,8,16].includes(depth)||(color===3&&depth===16)||data[10]||data[11]||interlace>1)bad("format",name);
  }else if(type==="IDAT"){if(closedIdat)bad("corrupt",name);seenIdat=true;chunks.push(data)}
  else if(type==="IEND"){if(n!==0||!seenIdat)bad("corrupt",name);ended=true;p+=12;break}
  else{
   if(seenIdat)closedIdat=true;
   if(["acTL","fcTL","fdAT","iCCP","zTXt","iTXt"].includes(type)||(!["PLTE"].includes(type)&&type[0]===type[0].toUpperCase()))bad("format",name);
  }
  p+=n+12;
 }
 if(!ended||p!==b.length)bad("corrupt",name);
 const passes=interlace?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]];
 let bytes=0;
 for(const [x,y,dx,dy] of passes){const w=Math.max(0,Math.ceil((width-x)/dx)),h=Math.max(0,Math.ceil((height-y)/dy));if(w&&h)bytes+=h*(1+Math.ceil(w*depth/8))}
 // Workerd accounts for decompressor allocation chunks as well as output.
 // Bounded slack avoids rejecting valid exact-size streams; exact length is checked below.
 let inflated;try{inflated=inflateSync(Buffer.concat(chunks),{maxOutputLength:bytes+65536})}catch{bad("corrupt",name)}
 if(inflated.length!==bytes)bad("corrupt",name);
 const labels=new Uint16Array(width*height);let pos=0;
 for(const [x,y,dx,dy] of passes){
  const w=Math.max(0,Math.ceil((width-x)/dx)),h=Math.max(0,Math.ceil((height-y)/dy));if(!w||!h)continue;
  const stride=Math.ceil(w*depth/8),bpp=Math.max(1,depth/8);let prev=new Uint8Array(stride);
  for(let row=0;row<h;row++){
   const filter=inflated[pos++];if(filter>4)bad("corrupt",name);const line=new Uint8Array(stride);
   for(let k=0;k<stride;k++){
    const a=k>=bpp?line[k-bpp]:0,c=k>=bpp?prev[k-bpp]:0,v=prev[k];
    line[k]=(inflated[pos++]+(filter===0?0:filter===1?a:filter===2?v:filter===3?Math.floor((a+v)/2):paeth(a,v,c)))&255;
   }
   for(let col=0;col<w;col++){
    const val=depth===16?(line[col*2]<<8)|line[col*2+1]:depth===8?line[col]:(line[Math.floor(col*depth/8)]>>(8-depth-(col*depth)%8))&((1<<depth)-1);
    labels[(y+row*dy)*width+x+col*dx]=val;
   }prev=line;
  }
 }
 return labels;
}
function ids(values){
 const map=new Map(),idx=new Uint32Array(values.length);
 for(let k=0;k<values.length;k++){const v=values[k];if(!map.has(v))map.set(v,map.size);idx[k]=map.get(v)}
 return [idx,map.size];
}
// Rectangular Hungarian assignment, deterministic raster-first ordering.
function assignment(tab,n,m){
 const transpose=n>m;
 const rows=Math.min(n,m),cols=Math.max(n,m),u=new Float64Array(rows+1),v=new Float64Array(cols+1),p=new Int32Array(cols+1),way=new Int32Array(cols+1);
 const cost=(i,j)=>-tab[transpose?j*m+i:i*m+j];
 for(let i=1;i<=rows;i++){
  p[0]=i;let j0=0;const min=new Float64Array(cols+1).fill(Infinity),used=new Uint8Array(cols+1);
  do{
   used[j0]=1;const i0=p[j0];let delta=Infinity,j1=0;
   for(let j=1;j<=cols;j++)if(!used[j]){
    const cur=cost(i0-1,j-1)-u[i0]-v[j];
    if(cur<min[j]){min[j]=cur;way[j]=j0}
    if(min[j]<delta){delta=min[j];j1=j}
   }
   for(let j=0;j<=cols;j++)if(used[j]){u[p[j]]+=delta;v[j]-=delta}else min[j]-=delta;
   j0=j1;
  }while(p[j0]!==0);
  do{const j1=way[j0];p[j0]=p[j1];j0=j1}while(j0);
 }
 const pairs=[];for(let j=1;j<=cols;j++)if(p[j])pairs.push(transpose?[j-1,p[j]-1]:[p[j]-1,j-1]);
 return pairs;
}
export function score(gt,pred,withAlignment=false){
 if(!gt.length||gt.length!==pred.length)bad("dimensions");
 const [g,ng]=ids(gt),[p,np]=ids(pred);
 if(ng*np>2_000_000)bad("classes");
 const tab=new Uint32Array(ng*np),ga=new Uint32Array(ng),pa=new Uint32Array(np);
 for(let k=0;k<g.length;k++){tab[g[k]*np+p[k]]++;ga[g[k]]++;pa[p[k]]++}
 let cs=0,ca=0,os=0,us=0,vi=0,pairIntersection=0;
 const osCount=new Uint32Array(ng),osSum=new Uint32Array(ng),usCount=new Uint32Array(np),usSum=new Uint32Array(np);
 const choose2=n=>n*(n-1)/2;
 for(let i=0;i<ng;i++)for(let j=0;j<np;j++){
  const t=tab[i*np+j];if(!t)continue;
  if(4*t>=3*ga[i]&&4*t>=3*pa[j])cs+=t;
  if(4*t>=3*pa[j]){osCount[i]++;osSum[i]+=t}
  if(4*t>=3*ga[i]){usCount[j]++;usSum[j]+=t}
  pairIntersection+=choose2(t);
  vi+=(t/gt.length)*(Math.log2(ga[i]/t)+Math.log2(pa[j]/t));
 }
 for(let i=0;i<ng;i++)if(osCount[i]>=2&&4*osSum[i]>=3*ga[i])os+=osSum[i];
 for(let j=0;j<np;j++)if(usCount[j]>=2&&4*usSum[j]>=3*pa[j])us+=usSum[j];
 const pairGT=ga.reduce((s,n)=>s+choose2(n),0),pairPred=pa.reduce((s,n)=>s+choose2(n),0),pairs=choose2(gt.length);
 // Divide before multiplying: exact counts fit JS integers for 512x512 images;
 // products of pair counts need not. Equal degenerate partitions have ARI=1.
 const expected=pairs?(pairGT/pairs)*pairPred:0,denominator=(pairGT+pairPred)/2-expected;
 const ari=denominator===0?1:(pairIntersection-expected)/denominator;
 const pairsMatched=assignment(tab,ng,np),alignment=new Int32Array(np).fill(-1);
 for(const [i,j] of pairsMatched){const t=tab[i*np+j];ca+=ga[i]*t/(ga[i]+pa[j]-t);if(t>0)alignment[j]=i}
 return {cs:cs/gt.length,ca:ca/gt.length,os:os/gt.length,us:us/gt.length,ari,vi,labels_gt:ng,labels_seg:np,...(withAlignment?{alignment}:{})};
}
function chunk(type,data){const t=Buffer.from(type),out=Buffer.alloc(data.length+12);out.writeUInt32BE(data.length,0);t.copy(out,4);data.copy(out,8);out.writeUInt32BE(crc32(out.subarray(4,8+data.length)),8+data.length);return out}
export function encodePng(labels,width,height,depth=8){
 const raw=Buffer.alloc(height*(1+width*(depth/8))),header=Buffer.alloc(13);
 header.writeUInt32BE(width,0);header.writeUInt32BE(height,4);header[8]=depth;
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){const offset=y*(1+width*(depth/8))+1+x*(depth/8),v=labels[y*width+x];if(depth===16)raw.writeUInt16BE(v,offset);else raw[offset]=v}
 return Buffer.concat([Buffer.from("89504e470d0a1a0a","hex"),chunk("IHDR",header),chunk("IDAT",deflateSync(raw)),chunk("IEND",Buffer.alloc(0))]);
}
function preview(labels,w,h){
 const [mapped]=ids(labels),size=64,out=new Uint8Array(size*size);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++)out[y*size+x]=mapped[Math.floor(y*h/size)*w+Math.floor(x*w/size)]%256;
 return Buffer.from(out).toString("base64");
}
export function colorPrediction(pred,width,height,alignment,palette){
 const [p]=ids(pred),raw=Buffer.alloc(height*(1+width*3)),header=Buffer.alloc(13);
 header.writeUInt32BE(width,0);header.writeUInt32BE(height,4);header[8]=8;header[9]=2;
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const k=y*width+x,label=p[k],matched=alignment[label];
  const border=(x>0&&p[k-1]!==label)||(y>0&&p[k-width]!==label);
  const color=border?[35,42,36]:matched>=0?palette[matched]:[190+(label*17)%60,55+(label*31)%55,165+(label*13)%75];
  const at=y*(1+width*3)+1+x*3;raw[at]=color[0];raw[at+1]=color[1];raw[at+2]=color[2];
 }
 return Buffer.concat([Buffer.from("89504e470d0a1a0a","hex"),chunk("IHDR",header),chunk("IDAT",deflateSync(raw)),chunk("IEND",Buffer.alloc(0))]);
}
/** @param {{references: Record<string,{palette:number[][]}>, save: (seg:string,png:Uint8Array)=>Promise<void>} | null} visuals */
export async function evaluate(raw,ds,key,type,onProgress=()=>{},visuals=null){
 const read=readUpload(raw,ds,type),xml=read("data.xml");
 if(xml&&await hash(xml)!==ds.xmlHash)bad("xml_mismatch");
 const truth=new Map(),rows=[],previews=[];
 let received=0;
 for(const c of ds.cases){
  const b=read(c.seg);
  if(!b){
   rows.push({group:c.group,tm:c.tm,seg:c.seg,gt:c.gt,status:"missing",seg_sha256:null,labels_seg:null,...Object.fromEntries(METRICS.map(k=>[k,0]))});
   previews.push(null);onProgress(rows.length);continue;
  }
  if(!truth.has(c.gt)){truth.clear();const bytes=Buffer.from(ds.gt[c.gt],"base64");if(await hash(bytes)!==ds.gtHashes[c.gt])throw Error("Reference identity");truth.set(c.gt,pngLabels(bytes,...c.size))}
  const pred=pngLabels(b,...c.size,c.seg),{alignment,...scores}=score(truth.get(c.gt),pred,!!visuals);
  if(visuals){const v=visuals.references[c.seg];await visuals.save(c.seg,colorPrediction(pred,...c.size,alignment,v.palette))}
  received++;
  rows.push({group:c.group,tm:c.tm,seg:c.seg,gt:c.gt,status:"evaluated",seg_sha256:await hash(b),...scores});
  previews.push(preview(pred,...c.size));onProgress(rows.length);
 }
 const sums=Object.fromEntries(METRICS.map(k=>[k,rows.reduce((s,r)=>s+r[k],0)]));
 return {report:{protocol:PROTOCOL,metrics_revision:"six-metrics-v2-partial",dataset:key,xml_sha256:ds.xmlHash,xml_provided:!!xml,ignored_files:read.manifest.ignored,unit:"mixed",metric_units:METRIC_UNITS,aggregation:"mean_over_expected_images_missing_zero",count:received,expected_count:rows.length,missing_count:rows.length-received,coverage:received/rows.length,visuals:!!visuals,
   summary:Object.fromEntries(METRICS.map(k=>[k,sums[k]/rows.length])),summary_observed:Object.fromEntries(METRICS.map(k=>[k,sums[k]/received])),images:rows},previews};
}
export function csv(report){
 return [["scope","tm","seg","gt",...METRICS.map(k=>k+"_"+METRIC_UNITS[k]),"status"],["mean","","","",...METRICS.map(k=>report.summary[k]??""),report.missing_count?"missing_zero_filled":"complete"],
 ...report.images.map(r=>["image",r.tm,r.seg,r.gt,...METRICS.map(k=>r[k]??""),r.status??"evaluated"])].map(r=>r.join(",")).join("\r\n")+"\r\n";
}
export function zipStored(files){
 let offset=0;const locals=[],central=[];
 for(const [name,raw] of files){
  const b=Buffer.from(raw),n=Buffer.from(name),crc=crc32(b),local=Buffer.alloc(30),cd=Buffer.alloc(46);
  local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt32LE(crc,14);local.writeUInt32LE(b.length,18);local.writeUInt32LE(b.length,22);local.writeUInt16LE(n.length,26);
  cd.writeUInt32LE(0x02014b50);cd.writeUInt16LE(20,4);cd.writeUInt16LE(20,6);cd.writeUInt32LE(crc,16);cd.writeUInt32LE(b.length,20);cd.writeUInt32LE(b.length,24);cd.writeUInt16LE(n.length,28);cd.writeUInt32LE(offset,42);
  locals.push(local,n,b);central.push(cd,n);offset+=30+n.length+b.length;
 }
 const c=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(c.length,12);end.writeUInt32LE(offset,16);
 return Buffer.concat([...locals,c,end]);
}

