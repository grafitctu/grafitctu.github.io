// Local entry point to the same evaluator used by the course Mosaic.
import {readFileSync, writeFileSync} from 'node:fs';
import {csv, evaluate} from './evaluate.mjs';

const submission = process.argv[2] || new URL('./ROZ-test.zip', import.meta.url);
const references = JSON.parse(readFileSync(new URL('./cvut2016-zimni.json', import.meta.url), 'utf8'));
const {report} = await evaluate(readFileSync(submission), references, 'cvut2016-zimni', 'application/zip');
console.log('CVUT2016_zimni: %d/%d images', report.count, report.expected_count);
for (const metric of ['cs','ca']) {
  console.log(metric.toUpperCase() + ' ' + (100*report.summary[metric]).toFixed(2) + '%');
}
if (process.argv[3]) writeFileSync(process.argv[3], csv(report));
