Česky: Rozbalte ZIP. Ve složce spusťte příkaz níže pomocí Node.js 22.13 nebo novějšího. První příkaz vyhodnotí přiložený historický ROZ-test. Pro vlastní SEG použijte druhý příkaz. Při úplném odevzdání budou vyhodnoceny všech 80 obrazů. CSV má jeden řádek na obraz.

English: Extract the ZIP. In its folder run these commands using Node.js 22.13 or later. The first evaluates the included historical ROZ-test. The second accepts your school submission and writes per-image scores. All processing is local.

node score-zip.mjs
node score-zip.mjs my-submission.zip scores.csv

ROZ-test: 80/80, CS 15.81%, CA 44.30%. Complete A/B submissions are in mosaic-classroom.zip. Source evaluator SHA-256: 61361bb2d18b625744e09d6b83cfcc94880c9260d379fad4e35e81ff6d01f65f
