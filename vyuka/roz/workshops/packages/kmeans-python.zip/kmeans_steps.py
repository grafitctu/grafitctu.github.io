def print_step(iteration, labels, centres, stable):
    numbers = " ".join(str(j + 1) for j in labels)
    positions = " ".join(f"({x:.6f}, {y:.6f})" for x, y in centres)
    print(f"{iteration}  labels {numbers}  centres {positions}" + ("  stable" if stable else ""))


def kmeans(points, centres):
    if not centres:
        raise ValueError("Supply at least one centre")
    centres = list(centres)
    labels = []
    iteration = 1
    while True:
        next_labels = []
        for x, y in points:
            nearest = 0
            best = float("inf")
            for j, (cx, cy) in enumerate(centres):
                d2 = (x - cx) ** 2 + (y - cy) ** 2
                if d2 < best:
                    best = d2
                    nearest = j
            next_labels.append(nearest)
        if next_labels == labels:
            print_step(iteration, labels, centres, True)
            return labels, centres
        labels = next_labels

        sum_x = [0.0] * len(centres)
        sum_y = [0.0] * len(centres)
        counts = [0] * len(centres)
        for (x, y), j in zip(points, labels):
            sum_x[j] += x
            sum_y[j] += y
            counts[j] += 1
        for j, count in enumerate(counts):
            if count > 0:
                centres[j] = (sum_x[j] / count, sum_y[j] / count)
        print_step(iteration, labels, centres, False)
        iteration += 1


if __name__ == "__main__":
    points = [(1, 1), (1.4, 2), (2, 1), (2, 3), (6, 5), (7, 6), (8, 5)]
    kmeans(points, [(1, 1), (2, 3)])
