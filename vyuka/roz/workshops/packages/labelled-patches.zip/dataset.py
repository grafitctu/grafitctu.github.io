"""Derive a balanced, labelled crop experiment from the original supervised Mosaic ZIP."""
import argparse
import base64
import csv
import hashlib
import io
import json
from pathlib import Path
import random
import re
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
from PIL import Image

DEFAULT_ARCHIVE = Path("prague_static_colour_supervised_normal.zip")
DEFAULT_OUT = Path("rebuilt")
CLASSES = ("bark", "flowers", "glass", "rock", "textile", "wood")
FEATURES = ("mean_r", "mean_g", "mean_b", "sd_r", "sd_g", "sd_b", "contrast_right", "contrast_down")
SEED = 20261118
SIZE = 64

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def image_features(pixels):
    rgb = pixels.astype(np.float64)
    # Quantise the arithmetic RGB mean without floating-point boundary ambiguity.
    grey = (pixels.astype(np.int32).sum(axis=2) * 4 // 768).astype(np.int16)
    dx = grey[:, 1:] - grey[:, :-1]
    dy = grey[1:, :] - grey[:-1, :]
    values = [*rgb.mean(axis=(0, 1)), *rgb.std(axis=(0, 1)), (dx*dx).mean(), (dy*dy).mean()]
    return [float(x) for x in values], grey

def pack_levels(grey):
    blocks = grey.ravel().reshape(-1, 4).astype(np.uint8)
    bits = (blocks[:, 0] << 6) | (blocks[:, 1] << 4) | (blocks[:, 2] << 2) | blocks[:, 3]
    return base64.b64encode(bits.tobytes()).decode("ascii")

def write_csv(path, records):
    with path.open("w", newline="", encoding="utf8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)

def build(archive, out):
    data = out / "data"
    data.mkdir(parents=True, exist_ok=True)
    parents, rows, levels, source_rows = [], [], [], []
    sha_tile = set()
    sha_pixels = set()
    with zipfile.ZipFile(archive) as source:
        xml = source.read("data.xml")
        sets = ET.fromstring(xml).findall("section")
        for ci, category in enumerate(CLASSES):
            group, = [s for s in sets if s.findtext("var[@name='TexSet']", "").strip('"') == category]
            tm = group.find("section[@name='TMMap_1_1']")
            train = [v for v in tm.findall("var") if re.fullmatch(r"Train\d+\.A", v.get("name", ""))]
            assert len(train) == 6
            category_parents = []
            for v in sorted(train, key=lambda e:e.text):
                original = v.text.strip().strip('"')
                assert original.startswith(category + "/")
                raw = source.read(original)
                original_path = data / "originals" / original
                original_path.parent.mkdir(parents=True, exist_ok=True)
                original_path.write_bytes(raw)
                im = Image.open(io.BytesIO(raw)).convert("RGB")
                w, h = im.size
                assert (w, h) == (int(v.get("cols")), int(v.get("rows"))) and min(w,h) >= 4*SIZE
                assert digest(im.tobytes()) not in sha_pixels, original
                sha_pixels.add(digest(im.tobytes()))
                pi = len(parents)
                parent = {"path": original, "width": w, "height": h, "classIndex": ci, "sha256": digest(raw)}
                parents.append(parent)
                category_parents.append(pi)
                source_rows.append({"original": original, "class_name": category, "width": w, "height": h,
                                    "source_set":group.get("name"), "source_map":tm.get("name"),
                                    "source_entry":v.get("name"), "source_sha256":parent["sha256"]})
                folder = data / "crops" / category
                folder.mkdir(parents=True, exist_ok=True)
                for gy in range(4):
                    for gx in range(4):
                        x = (2*gx+1)*w // 8 - SIZE//2
                        y = (2*gy+1)*h // 8 - SIZE//2
                        tile = im.crop((x,y,x+SIZE,y+SIZE))
                        crop_id = Path(original).stem+f"-{gy}{gx}"
                        rel = f"crops/{category}/{crop_id}.png"
                        tile.save(data / rel)
                        fingerprint = digest(tile.tobytes())
                        assert fingerprint not in sha_tile, crop_id
                        sha_tile.add(fingerprint)
                        feat, grey = image_features(np.asarray(tile))
                        rows.append({"id":crop_id,"p":pi,"c":ci,"x":x,"y":y,"file":rel,"f":feat,
                                     "sha256":digest((data/rel).read_bytes())})
                        levels.append(pack_levels(grey))
            # Two pre-specified stratified six-fold partitions, independent of the features and scores.
            ids = [i for i,r in enumerate(rows) if r["c"] == ci]
            random.Random(f"{SEED}:crops:{category}").shuffle(ids)
            for pos, i in enumerate(ids):
                rows[i]["crop"] = pos // 16
            random.Random(f"{SEED}:originals:{category}").shuffle(category_parents)
            for fold, pi in enumerate(category_parents):
                parents[pi]["fold"] = fold
                for row in rows:
                    if row["p"] == pi: row["origin"] = fold
    assert len(rows) == 576 and len(parents) == 36
    for mode in ("crop","origin"):
        for fold in range(6):
            test = [r for r in rows if r[mode] == fold]
            assert [sum(r["c"]==k for r in test) for k in range(6)] == [16]*6
            if mode == "origin":
                assert {r["p"] for r in test}.isdisjoint(r["p"] for r in rows if r[mode] != fold)
    flat = [{"id":r["id"], "class_name":CLASSES[r["c"]], "original":parents[r["p"]]["path"],
             "x":r["x"], "y":r["y"], "size":SIZE, "fold_crop":r["crop"]+1, "fold_origin":r["origin"]+1,
             **dict(zip(FEATURES,r["f"])), "file":r["file"], "png_sha256":r["sha256"]} for r in rows]
    write_csv(data / "patches.csv",flat)
    write_csv(data / "originals.csv",source_rows)
    meta={"dataset_label":ET.fromstring(xml).findtext("var[@name='Label']").strip('"'),
          "input_archive":archive.name,"archive_sha256":digest(archive.read_bytes()),"xml_sha256":digest(xml),
          "paper":"https://library.utia.cas.cz/separaty/2021/RO/haindl-0545221.pdf",
          "benchmark":"https://mosaic.utia.cas.cz/","classes":CLASSES,"n_sources":len(parents),"n_crops":len(rows),
          "fold_seed":SEED,"feature_order":FEATURES,"original_identity":"archived Train*.A source image file; independent physical acquisitions undocumented"}
    (data / "provenance.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf8")
    (data / "source-data.xml").write_bytes(xml)
    js={"parents":parents,"rows":rows,"classes":CLASSES,"features":FEATURES}
    (data/"catalog.js").write_text("window.CropData="+json.dumps(js,ensure_ascii=False,separators=(",",":"))+";\n",encoding="utf8")
    (data/"levels.js").write_text("window.CropLevels="+json.dumps(levels,separators=(",",":"))+";\n",encoding="utf8")
    print(f"{len(rows)} crops from {len(parents)} checked parent images. XML {digest(xml)}")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive",type=Path,default=DEFAULT_ARCHIVE)
    parser.add_argument("--out",type=Path,default=DEFAULT_OUT)
    args=parser.parse_args()
    build(args.archive,args.out)
