cmake_minimum_required(VERSION 3.16)
project(biometrics LANGUAGES CXX)
add_executable(biometrics biometrics.cpp)
target_compile_features(biometrics PRIVATE cxx_std_17)
