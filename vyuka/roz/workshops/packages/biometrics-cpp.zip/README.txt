NI-ROZ / ANI-ROZ · biometrics

Příkazy spouštějte z rozbalené složky.
Run commands from the extracted folder.
C++17 a CMake / C++17 and CMake
  cmake -S . -B build
  cmake --build build --config Release
  Windows (Visual Studio): .\build\Release\biometrics.exe
  Linux/macOS: ./build/biometrics
  Bez CMake / without CMake: c++ -std=c++17 biometrics.cpp -o biometrics

Vstupní příklad je v hlavní funkci. Upravte jeho hodnoty a program spusťte znovu.
The input example is in the main block. Edit its values and run the program again.

https://grafitctu.github.io/vyuka/roz/feature-labs/
