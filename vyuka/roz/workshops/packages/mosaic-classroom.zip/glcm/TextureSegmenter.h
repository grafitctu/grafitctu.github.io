#pragma once
// Include after Segmenter.h, in place of the empty MySegmenter declaration.
#include "TBAlloc.h"
#include <algorithm>
#include <vector>

class MySegmenter : public Segmenter {
public:
  int features(DyXML_wrapper &par) override {
    const int status = Segmenter::features(par); // keep all three smoothed RGB planes
    if (status != 0 || nimg != 3 || nfeat != 3) return -1;

    constexpr int levels = 4;
    constexpr int radius = 4; // a 9 by 9 window in the image interior
    std::vector<int> grey(nr * nc);
    for (int y = 0; y < nr; ++y) {
      for (int x = 0; x < nc; ++x) {
        const float mean = (img[0][y][x] + img[1][y][x] + img[2][y][x]) / 3.0f;
        grey[y * nc + x] = std::clamp(int(mean * levels / 256.0f), 0, levels - 1);
      }
    }

    float ***withContrast = nullptr;
    vr_alloc(withContrast, 0, nfeat, 0, nr - 1, 0, nc - 1);
    for (int plane = 0; plane < nfeat; ++plane) {
      for (int y = 0; y < nr; ++y)
        std::copy_n(feat[plane][y], nc, withContrast[plane][y]);
    }
    for (int y = 0; y < nr; ++y) {
      for (int x = 0; x < nc; ++x) {
        const int left = std::max(0, x - radius), right = std::min(nc - 1, x + radius);
        const int top = std::max(0, y - radius), bottom = std::min(nr - 1, y + radius);
        int squaredSum = 0, pairs = 0;
        for (int row = top; row <= bottom; ++row) {
          for (int col = left; col <= right; ++col) {
            const int i = row * nc + col;
            if (col < right) {
              const int dx = grey[i] - grey[i + 1];
              squaredSum += dx * dx;
              ++pairs;
            }
            if (row < bottom) {
              const int dy = grey[i] - grey[i + nc];
              squaredSum += dy * dy;
              ++pairs;
            }
          }
        }
        // This equals sum((i-j)^2 * P[i,j]) for the pooled pair counts.
        // Map its possible range [0,9] to the same nominal [0,255] as RGB.
        const float contrast = pairs ? float(squaredSum) / pairs : 0.0f;
        withContrast[nfeat][y][x] = 255.0f * contrast / ((levels - 1) * (levels - 1));
      }
    }
    vr_free(feat, 0, nfeat - 1, 0, nr - 1, 0, nc - 1);
    feat = withContrast;
    ++nfeat;
    return 0;
  }
};
