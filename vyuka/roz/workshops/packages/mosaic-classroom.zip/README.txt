NI-ROZ / ANI-ROZ · Mosaic · podklady ke koncepci / teaching materials
18. 11. 2026

ČESKY

1. Okamžitá ukázka ve třídě
Rozbalte tento vnější ZIP. Na https://roz-mosaic.richtrad.chatgpt.site/
vyberte CVUT2016_zimni a otevřete submissions/03_Lab_blur.zip. Spočítejte
výsledek. Zopakujte s 04_Lab_std.zip. Oba vnitřní ZIPy obsahují totožné
data.xml a všech 80 jednopásmových SEG PNG v kořeni. První balík používá
lokální průměry tří kanálů Lab, druhý přidává tři lokální směrodatné
odchylky. Stejný C++17 k-means, K, způsob inicializace i sada obrazů.
Očekávejte CS/CA 18,17/45,00 a 18,55/47,00 procent. Záznam lze ponechat
soukromý. V učební stránce jsou stejné ukázky již vyhodnocené i offline.

2. Zopakování pokusu s PCA v původním C++ Segmenteru 18
Rozbalte školní segmenter18-cpp-data.zip. Plnou sadu RGB mozaik
CVUT2016_zimni dejte do data/ podle návodu u cvičení 02. Konfigurace
configs/demo-0.xml až demo-3.xml zkopírujte vedle main.cpp. V tomto adresáři
vytvořte složky demo-0, demo-1, demo-2 a demo-3. Aplikaci sestavte podle
školního README. Každý soubor spusťte s původním main.cpp. Příklad pro Windows:

    .\segmenter.exe demo-1.xml

Na Linuxu použijte ./segmenter demo-1.xml. Stejná data a známé K, postupně
kl_trans = 0 (vypnuto), 1, 2 a 3. Každý běh vytvoří 16 predikcí pro skupiny
1, 6, 11 a 16 a vypíše polohu výsledků. Shodu kontrolujte podle řádků v
scores.csv; porovnání pro výuku připouští drobné číselné rozdíly mezi sestaveními.
Průměr v pilotu má jmenovatel 16. Při dílčím nahrání na školní web sledujte
průměr přes dodané obrazy nebo spočítejte průměr 16 přítomných řádků CSV.
Celkové skóre dílčího odevzdání tam má jmenovatel 80.

3. Jeden příznak navíc
Rozbalte druhou kopii stejného zdrojového projektu. V ní použijte přiložený
glcm/main.cpp a glcm/TextureSegmenter.h vedle Segmenter.h, stejná RGB data,
configs/demo-contrast.xml a adresář demo-contrast. Sestavte ho a spusťte
nad demo-contrast.xml. Základní tři vyhlazené RGB roviny doplní jeden
kontrast ze čtyř úrovní šedi. Počítají se dvojice vpravo a dolů uvnitř
okna 9 × 9, u okraje se okno ořízne. Výsledek se přepočítá z [0,9] na
[0,255]. PCA je vypnutá. V konzoli zkontrolujte čtyři rozměry příznaku.
Na druhé vyučovací implementaci C++17 (ZIPy z kroku 1) není tento pokus založený.

4. Co obsahuje scores.csv
Každý řádek je jeden SEG určité varianty. Tabulka obsahuje původní ROZ-test
pro všech 80 obrazů, deset již existujících metod C++17 po 80 obrazech
a pět nastavení Segmenteru 18 po 16 obrazech. CS a CA jsou procenta.
Podíl rozptylu je spočten z vlastních čísel vypsaných programem. Označení
ground_truth_file slouží k dohledání reference v data.xml. Referenční mapy
používá vyhodnocovač. Pro rekonstrukci vlastního klasifikátoru semestrální
práce se použije samostatné rozdělení označených dat.

ENGLISH

1. Run a classroom demonstration
Extract this outer ZIP. At https://roz-mosaic.richtrad.chatgpt.site/ select
CVUT2016_zimni. Submit submissions/03_Lab_blur.zip, then 04_Lab_std.zip.
Each inner ZIP contains the same data.xml and 80 single-channel SEG PNGs at
its root. The first uses three local Lab means. The second adds three local
standard deviations. Both use the same C++17 k-means, K, initialisation
procedure and images. Expect CS/CA of 18.17/45.00 and 18.55/47.00 percent.
The result can stay private. The teaching page also shows these results offline.

2. Repeat the PCA experiment with the original C++ Segmenter 18
Extract the course package segmenter18-cpp-data.zip. Put the full
CVUT2016_zimni RGB mosaic set inside data/ as explained in Tutorial 02.
Copy configs/demo-0.xml through demo-3.xml next to main.cpp. Create output
directories demo-0, demo-1, demo-2 and demo-3. Compile the program using
the course README. Use the original main.cpp for all four runs.

    .\segmenter.exe demo-1.xml

On Linux use ./segmenter demo-1.xml. All runs use identical images and known
K. kl_trans = 0 disables PCA. Values 1, 2 and 3 retain that many components.
Each run writes 16 predictions for groups 1, 6, 11 and 16. Check individual
results against scores.csv. Small numerical differences between builds are
possible. The pilot averages over 16 images. For a partial web submission,
read the mean for submitted images or average the 16 evaluated CSV rows.
The website divides the overall partial score by 80.

3. Add a single feature
Use a second copy of the original source project. Place glcm/main.cpp and
glcm/TextureSegmenter.h next to Segmenter.h, use the same RGB data, copy
configs/demo-contrast.xml there and create a demo-contrast output directory.
Compile and run with demo-contrast.xml. The program extends the three
smoothed RGB features with contrast on four grey levels. It counts right
and downward pairs inside a 9 × 9 window, clipped at image borders. It maps
contrast from [0,9] to [0,255]. PCA is disabled. Check that the console
reports four feature dimensions. Section 1 uses a separate C++17 implementation.

4. Read scores.csv
Each row is one SEG from one variant. The file covers the original 80-image
ROZ-test, ten existing C++17 variants on all 80 images, and five Segmenter
18 settings on 16 images each. CS and CA are percentages. Retained variance
comes from the eigenvalues printed in the program log. ground_truth_file
identifies the reference from data.xml. Ground truth is read by the evaluator.
The supervised semester project uses a separate split of its labelled data.
