Rozbalte ZIP a v jeho složce spusťte příkazy.
Extract the ZIP and run these commands in its folder.

Python 3 (standard library):
python scores.py

4 × 4 pixels, two regions: perfect and renamed 100/100, merged 0/25, exchange 87.5/77.777778 (CS/CA, %).
