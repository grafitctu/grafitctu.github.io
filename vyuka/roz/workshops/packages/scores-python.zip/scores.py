"""Two-region examples for the classroom, using Python's standard library."""
def scores(truth, prediction):
    refs = list(dict.fromkeys(truth))
    labels = list(dict.fromkeys(prediction))
    if len(labels) == 1:
        labels.append(1-labels[0])  # empty second region for the one-to-one assignment
    counts = {(g,p): 0 for g in refs for p in labels}
    for pair in zip(truth,prediction):
        counts[pair] += 1
    g_size = {g: truth.count(g) for g in refs}
    p_size = {p: prediction.count(p) for p in labels}
    credit = sum(n for (g,p),n in counts.items() if 4*n >= 3*g_size[g] and 4*n >= 3*p_size[p])
    orders = [labels, labels[::-1]]
    chosen = max(orders, key=lambda order: sum(counts[g,p] for g,p in zip(refs,order)))
    weighted_iou = 0
    for g,p in zip(refs,chosen):
        n = counts[g,p]
        weighted_iou += g_size[g]*n/(g_size[g]+p_size[p]-n)
    return credit/len(truth), weighted_iou/len(truth)

if __name__ == "__main__":
    truth = [0,0,1,1]*4
    exchanged = truth.copy()
    exchanged[0], exchanged[2] = exchanged[2], exchanged[0]
    for mode, predicted in [("perfect",truth),("renamed",[1-v for v in truth]),
                            ("merged",[0]*16),("exchange",exchanged)]:
        cs,ca = scores(truth,predicted)
        print(f"{mode} CS {100*cs:.6f}% CA {100*ca:.6f}%")
