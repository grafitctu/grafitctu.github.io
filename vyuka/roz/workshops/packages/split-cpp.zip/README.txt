Rozbalte ZIP a v jeho složce spusťte příkazy.
Extract the ZIP and run these commands in its folder.

Linux / macOS:
c++ -std=c++17 -O2 split.cpp -o split
./split

Windows (Developer PowerShell / x64 Native Tools for Visual Studio):
cl /nologo /EHsc /std:c++17 /O2 split.cpp
.\split.exe

Výsledek / Output: crop 475/576, origin 117/576; predictions.csv.
