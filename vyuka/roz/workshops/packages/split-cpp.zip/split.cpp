// C++17. Run: split patches.csv predictions.csv
#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using Features = std::array<double, 8>;
struct Patch {
    std::string id, label, original;
    int cropFold, originFold;
    Features features;
};

// All fields in the distributed CSV are plain numbers or portable file names.
std::vector<std::string> fields(const std::string& line) {
    std::istringstream stream(line);
    std::string field;
    std::vector<std::string> result;
    while (std::getline(stream, field, ',')) result.push_back(field);
    return result;
}

std::vector<Patch> load(const std::string& file) {
    std::ifstream input(file);
    if (!input) throw std::runtime_error("Cannot open " + file);
    std::string line;
    std::getline(input, line);
    auto header = fields(line);
    std::map<std::string, size_t> at;
    for (size_t i = 0; i < header.size(); ++i) at[header[i]] = i;
    const std::array<std::string, 8> names = {"mean_r", "mean_g", "mean_b", "sd_r", "sd_g", "sd_b", "contrast_right", "contrast_down"};
    std::vector<Patch> rows;
    while (std::getline(input, line)) {
        if (line.empty()) continue;
        const auto row = fields(line);
        auto get = [&](const std::string& key) {return row.at(at.at(key));};
        Patch p{get("id"), get("class_name"), get("original"),
                std::stoi(get("fold_crop")), std::stoi(get("fold_origin")), {}};
        for (size_t k = 0; k < names.size(); ++k) p.features[k] = std::stod(get(names[k]));
        rows.push_back(p);
    }
    if (rows.empty()) throw std::runtime_error("Empty dataset");
    return rows;
}

int evaluate(const std::vector<Patch>& patches, bool groupByOriginal, int fold, std::ostream& output) {
    std::vector<size_t> train, test;
    for (size_t i = 0; i < patches.size(); ++i) {
        int assigned = groupByOriginal ? patches[i].originFold : patches[i].cropFold;
        (assigned == fold ? test : train).push_back(i);
    }
    if (train.empty() || test.empty()) throw std::runtime_error("Empty fold");
    Features mean{}, scale{};
    for (size_t i : train)
        for (size_t k = 0; k < mean.size(); ++k) mean[k] += patches[i].features[k];
    for (double& m : mean) m /= train.size();
    for (size_t i : train)
        for (size_t k = 0; k < mean.size(); ++k) {
            double d = patches[i].features[k] - mean[k];
            scale[k] += d*d;
        }
    for (double& s : scale) s = s > 0 ? std::sqrt(s/train.size()) : 1;
    std::vector<Features> z(patches.size());
    for (size_t i = 0; i < patches.size(); ++i)
        for (size_t k = 0; k < mean.size(); ++k)
            z[i][k] = (patches[i].features[k] - mean[k]) / scale[k];
    int correct = 0;
    for (size_t i : test) {
        double best = std::numeric_limits<double>::infinity();
        size_t nearest = train.front();
        for (size_t j : train) {
            double distance = 0;
            for (size_t k = 0; k < mean.size(); ++k) {
                double d = z[i][k] - z[j][k];
                distance += d*d;
            }
            if (distance < best || (distance == best && patches[j].id < patches[nearest].id)) {
                best = distance;
                nearest = j;
            }
        }
        const auto& sample = patches[i];
        const auto& neighbour = patches[nearest];
        correct += sample.label == neighbour.label;
        output << (groupByOriginal ? "origin" : "crop") << ',' << fold << ','
               << sample.id << ',' << sample.label << ',' << neighbour.label << ','
               << neighbour.id << ',' << std::sqrt(best) << ',' << (sample.original == neighbour.original) << '\n';
    }
    return correct;
}

int main(int argc, char** argv) {
    try {
        const auto rows = load(argc > 1 ? argv[1] : "patches.csv");
        std::ofstream out(argc > 2 ? argv[2] : "predictions.csv");
        if (!out) throw std::runtime_error("Cannot open output CSV");
        out << std::setprecision(17) << "mode,fold,id,truth,prediction,nearest,distance,same_original\n";
        for (bool group : {false,true}) {
            int correct = 0;
            for (int fold = 1; fold <= 6; ++fold) correct += evaluate(rows, group, fold, out);
            std::cout << (group ? "origin: " : "crop: ") << correct << '/' << rows.size() << '\n';
        }
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
