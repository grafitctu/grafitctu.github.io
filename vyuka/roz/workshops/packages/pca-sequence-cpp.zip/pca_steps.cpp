#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using Point = std::array<double, 2>;
using Matrix = std::array<Point, 2>;
using std::vector;
struct Data { vector<Point> points; Matrix covariance; };
struct Axes { Point eigenvalues, pc1, pc2; };

// 1. Matrix times vector
Point transform(const Matrix& matrix, Point v) {
    Point result{};
    for (int row = 0; row < 2; ++row)
        result[row] = matrix[row][0] * v[0] + matrix[row][1] * v[1];
    return result;
}

// 2. Test an eigendirection
double direction_error(const Matrix& matrix, Point u) {
    Point au = transform(matrix, u);
    // The determinant of the two arrows is zero when they lie on one line.
    return std::abs(u[0] * au[1] - u[1] * au[0]);
}

// 3. Measure the stretch along an eigendirection
double stretch(const Matrix& matrix, Point u) {
    // For a nonzero eigenvector this length ratio gives the absolute eigenvalue.
    Point au = transform(matrix, u);
    return std::hypot(au[0], au[1]) / std::hypot(u[0], u[1]);
}

void print_stretches(const char* name, const Matrix& matrix) {
    // All three matrices share these eigenlines. Normalising the arrows gives the same ratios.
    double first = stretch(matrix, {1, 1});
    double second = stretch(matrix, {-1, 1});
    std::cout << "3  stretch " << name << "  " << first << ' ' << second << '\n';
}

// 4. Centre height and weight, then calculate sample covariance
Data covariance(const vector<Point>& measurements) {
    double n = static_cast<double>(measurements.size());
    Point mean{};
    for (auto [h, w] : measurements) { mean[0] += h; mean[1] += w; }
    mean[0] /= n;
    mean[1] /= n;
    Data data{};
    for (auto [height, weight] : measurements) {
        Point x{(height - mean[0]) / 5, (weight - mean[1]) / 4};
        data.points.push_back(x);
        for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 2; ++j)
                data.covariance[i][j] += x[i] * x[j];
    }
    for (auto& row : data.covariance)
        for (double& entry : row) entry /= n - 1;
    return data;
}

// 5. Find the principal axes of the symmetric covariance matrix
Axes principal_axes(const Matrix& matrix) {
    double a = matrix[0][0], b = matrix[0][1], d = matrix[1][1];
    double gap = std::hypot(a - d, 2 * b);
    double angle = std::atan2(2 * b, a - d) / 2;
    Point pc1{std::cos(angle), std::sin(angle)};
    return {{(a + d + gap) / 2, (a + d - gap) / 2},
            pc1, {-pc1[1], pc1[0]}};
}

// 6. Project each centred point onto a unit axis
vector<double> project(const vector<Point>& points, Point axis) {
    vector<double> scores;
    for (auto [h, w] : points)
        scores.push_back(h * axis[0] + w * axis[1]);
    return scores;
}

// 7. Count the one-dimensional scores in equal-width bins
vector<int> histogram(const vector<double>& scores, int bins) {
    auto [low, high] = std::minmax_element(scores.begin(), scores.end());
    vector<int> counts(bins, 0);
    for (double score : scores) {
        double relative = *high > *low ? (score - *low) / (*high - *low) : 0;
        int index = std::min(static_cast<int>(relative * bins), bins - 1);
        ++counts[index];
    }
    return counts;
}

// Run all seven steps
int main(int argc, char** argv) {
    std::ifstream file(argc > 1 ? argv[1] : "measurements.csv");
    std::string row;
    if (!std::getline(file, row)) { std::cerr << "Cannot read measurements.csv\n"; return 1; }
    vector<Point> measurements;
    while (std::getline(file, row)) {
        std::istringstream cells(row);
        double h, w;
        char comma;
        if (!(cells >> h >> comma >> w) || comma != ',') { std::cerr << "Invalid CSV row\n"; return 1; }
        measurements.push_back({h, w});
    }
    if (measurements.size() < 2) { std::cerr << "Supply at least two measurements\n"; return 1; }
    Matrix matrix{{{1.25, 0.75}, {0.75, 1.25}}};
    Point av = transform(matrix, {2, -0.5});
    std::cout << std::fixed << std::setprecision(6) << "1  Av " << av[0] << ' ' << av[1] << '\n';
    double q = 1 / std::sqrt(2.0);
    Point first{q, q}, second{-q, q};
    for (Point u : {first, second}) std::cout << "2  direction error " << direction_error(matrix, u) << '\n';
    print_stretches("A", matrix);
    print_stretches("B", Matrix{{{2, 1}, {1, 2}}});
    print_stretches("3I", Matrix{{{3, 0}, {0, 3}}});
    Data data = covariance(measurements);
    std::cout << "4  covariance";
    for (auto r : data.covariance) for (double value : r) std::cout << ' ' << value;
    Axes axes = principal_axes(data.covariance);
    std::cout << "\n5  eigenvalues " << axes.eigenvalues[0] << ' ' << axes.eigenvalues[1] << '\n';
    auto scores = project(data.points, axes.pc1);
    std::cout << "6  first PC1 score " << scores.front() << "\n7  bin counts";
    for (int count : histogram(scores, 10)) std::cout << ' ' << count;
    std::cout << '\n';
}
