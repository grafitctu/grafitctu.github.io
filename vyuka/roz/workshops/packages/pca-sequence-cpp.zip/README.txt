Od jedné šipky k PCA / From one arrow to PCA

Rozbalte oba soubory do jedné složky a spusťte příklad v této složce. Sedm částí programu odpovídá sedmi krokům ve cvičení.
Extract the files into one folder and run the example there. The seven sections of the program match the seven steps in the workshop.

Windows (Developer PowerShell for Visual Studio)
cl /nologo /EHsc /std:c++17 pca_steps.cpp
.\pca_steps.exe

Linux / macOS
c++ -std=c++17 pca_steps.cpp -o pca_steps
./pca_steps

V kroku 3 porovnejte vždy tutéž šipku. Sloupce výstupu patří směrům 45° a 135°. Matice A dává násobky 2 a 0,5, B dává 3 a 1 a matice 3I dává 3 v každém směru.
In step 3 compare the same arrow each time. The output columns correspond to 45° and 135°. The factors are 2 and 0.5 for A, 3 and 1 for B, and 3 in every direction for 3I.

Ve 4. kroku začněte první dvojicí v CSV (177,5 cm a 72 kg). Odečtením průměrů 170 cm a 70 kg získáte 7,5 cm a 2 kg. V jednotkách po 5 cm a 4 kg je to h = 1,5 a w = 0,5. Sečtěte h², h × w a w² přes všech 64 řádků. Součty 78,75, 47,25 a 78,75 vydělte 63. Matice má na diagonále výběrové rozptyly 1,25 a mimo ni kovarianci 0,75. Skóre prvního bodu na PC1 je √2.
In step 4, start with the first CSV row (177.5 cm and 72 kg). Subtract the means of 170 cm and 70 kg to get 7.5 cm and 2 kg. In units of 5 cm and 4 kg, these become h = 1.5 and w = 0.5. Sum h², h × w and w² over all 64 rows. Divide the sums of 78.75, 47.25 and 78.75 by 63. The diagonal entries are the sample variances of 1.25. The off-diagonal covariance is 0.75. The first PC1 score is √2.
