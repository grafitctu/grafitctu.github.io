Kovarianční a kookurenční matice / Covariance and co-occurrence matrices

Rozbalte ZIP a spusťte příkaz v jeho složce. Program vypíše výběrovou kovarianci kanálů R a G, orientovanou GLCM a výběrovou kovarianci sousedních jasů.
Extract the ZIP and run the command in its folder. The program prints sample R,G covariance, directed GLCM counts and sample covariance of neighbouring grey levels.

Windows (Developer PowerShell for Visual Studio)
cl /nologo /EHsc /std:c++17 compare.cpp
.\compare.exe
.\compare.exe bark shuffled down

Linux / macOS
c++ -std=c++17 compare.cpp -o compare
./compare
./compare bark shuffled down

Arguments: [stripes|bark] [original|shuffled] [right|down|left|right2]

pixels.csv: x a y začínají od nuly. Sloupec shuffled_slot určuje novou pozici celého pixelu při promíchání (po řádcích). Kůra je výřez 4 × 4 od x=56, y=35 z bark10_t0-00, školní datová sada Mosaic Colour [normal] CL.
Pixel x and y start at zero. shuffled_slot gives the new row-major position of the whole pixel. Bark is a 4 × 4 excerpt at x=56, y=35 from bark10_t0-00 in the course Mosaic Colour [normal] CL dataset.
