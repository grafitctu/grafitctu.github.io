#include <algorithm>
#include <array>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using Pair = std::array<double, 2>;
using Covariance = std::array<Pair, 2>;
using Grid = std::array<std::array<int, 4>, 4>;

Covariance sample_covariance(const std::vector<Pair>& rows) {
    if (rows.size() < 2) throw std::invalid_argument("Sample covariance needs two or more observations");
    const double n = static_cast<double>(rows.size());
    Pair means{};
    for (auto [x, y] : rows) { means[0] += x; means[1] += y; }
    means[0] /= n;
    means[1] /= n;
    Covariance matrix{};
    for (auto [x, y] : rows) {
        Pair d{x - means[0], y - means[1]};
        for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 2; ++j)
                matrix[i][j] += d[i] * d[j];
    }
    for (auto& row : matrix)
        for (double& entry : row) entry /= n - 1;
    return matrix;
}

Grid cooccurrence(const Grid& levels, int dx, int dy) {
    Grid counts{};
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            int nx = x + dx, ny = y + dy;
            if (nx >= 0 && nx < 4 && ny >= 0 && ny < 4) {
                int a = levels[y][x], b = levels[ny][nx];
                ++counts[a][b];
            }
        }
    }
    return counts;
}

double neighbour_covariance(const Grid& counts) {
    double m = 0, sum_a = 0, sum_b = 0;
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j) {
            int count = counts[i][j];
            m += count;
            sum_a += count * i;
            sum_b += count * j;
        }
    if (m < 2) throw std::invalid_argument("Sample covariance needs two or more pairs");
    double total = 0;
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j)
            total += counts[i][j] * (i - sum_a / m) * (j - sum_b / m);
    return total / (m - 1);
}

int main(int argc, char** argv) {
    const std::string tile = argc > 1 ? argv[1] : "stripes";
    const std::string order = argc > 2 ? argv[2] : "original";
    const std::string direction = argc > 3 ? argv[3] : "right";
    const std::map<std::string, std::array<int, 2>> offsets{
        {"right", {1, 0}}, {"down", {0, 1}}, {"left", {-1, 0}}, {"right2", {2, 0}}};
    if (argc > 4 || (tile != "stripes" && tile != "bark") ||
        (order != "original" && order != "shuffled") || !offsets.count(direction)) {
        std::cerr << "Use [stripes|bark] [original|shuffled] [right|down|left|right2]\n";
        return 1;
    }
    std::ifstream file("pixels.csv");
    std::string line;
    if (!std::getline(file, line)) { std::cerr << "Cannot open pixels.csv\n"; return 1; }
    std::vector<Pair> channels(16);
    std::array<bool, 16> seen{};
    Grid levels{};
    while (std::getline(file, line)) {
        std::replace(line.begin(), line.end(), ',', ' ');
        std::istringstream row(line);
        std::string name;
        int x, y, r, g, b, slot;
        if (!(row >> name >> x >> y >> r >> g >> b >> slot)) { std::cerr << "Invalid CSV row\n"; return 1; }
        if (name != tile) continue;
        int index = order == "shuffled" ? slot : 4 * y + x;
        if (index < 0 || index >= 16 || seen[index] || r < 0 || r > 255 ||
            g < 0 || g > 255 || b < 0 || b > 255) { std::cerr << "Invalid pixel\n"; return 1; }
        seen[index] = true;
        channels[index] = {double(r / 64), double(g / 64)};
        levels[index / 4][index % 4] = (r + g + b) / 192;
    }
    if (std::find(seen.begin(), seen.end(), false) != seen.end()) { std::cerr << "Missing pixels\n"; return 1; }
    auto [dx, dy] = offsets.at(direction);
    Grid counts = cooccurrence(levels, dx, dy);
    std::cout << std::fixed << std::setprecision(6) << "S\n";
    for (auto [s1, s2] : sample_covariance(channels)) std::cout << s1 << ' ' << s2 << '\n';
    std::cout << "C\n";
    int pairs = 0;
    for (auto row : counts) {
        std::cout << row[0] << ' ' << row[1] << ' ' << row[2] << ' ' << row[3] << '\n';
        for (int count : row) pairs += count;
    }
    std::cout << "pairs " << pairs << "\ncov(A,B) " << neighbour_covariance(counts) << '\n';
}
