#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>

using std::size_t;
using std::vector;

struct Point { double x, y; };
struct Result { vector<size_t> labels; vector<Point> centres; };

void print_step(int iteration, const vector<size_t>& labels,
                const vector<Point>& centres, bool stable) {
    std::cout << iteration << "  labels";
    for (size_t label : labels) std::cout << ' ' << label + 1;
    std::cout << "  centres" << std::fixed << std::setprecision(6);
    for (Point c : centres) std::cout << " (" << c.x << ", " << c.y << ')';
    std::cout << (stable ? "  stable\n" : "\n");
}

Result kmeans(const vector<Point>& points, vector<Point> centres) {
    if (centres.empty()) throw std::invalid_argument("Supply at least one centre");
    vector<size_t> labels;
    for (int iteration = 1; ; ++iteration) {
        vector<size_t> next_labels;
        for (Point p : points) {
            size_t nearest = 0;
            double best = std::numeric_limits<double>::infinity();
            for (size_t j = 0; j < centres.size(); ++j) {
                double dx = p.x - centres[j].x;
                double dy = p.y - centres[j].y;
                double d2 = dx * dx + dy * dy;
                if (d2 < best) {
                    best = d2;
                    nearest = j;
                }
            }
            next_labels.push_back(nearest);
        }
        if (next_labels == labels) {
            print_step(iteration, labels, centres, true);
            return {labels, centres};
        }
        labels = next_labels;

        vector<Point> sums(centres.size(), {0.0, 0.0});
        vector<size_t> counts(centres.size(), 0);
        for (size_t i = 0; i < points.size(); ++i) {
            size_t j = labels[i];
            sums[j].x += points[i].x;
            sums[j].y += points[i].y;
            ++counts[j];
        }
        for (size_t j = 0; j < centres.size(); ++j) {
            if (counts[j] > 0) {
                centres[j] = {sums[j].x / counts[j], sums[j].y / counts[j]};
            }
        }
        print_step(iteration, labels, centres, false);
    }
}

int main() {
    const vector<Point> points{{1, 1}, {1.4, 2}, {2, 1}, {2, 3},
                               {6, 5}, {7, 6}, {8, 5}};
    kmeans(points, {{1, 1}, {2, 3}});
}
