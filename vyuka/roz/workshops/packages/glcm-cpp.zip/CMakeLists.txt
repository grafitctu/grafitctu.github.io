cmake_minimum_required(VERSION 3.16)
project(glcm LANGUAGES CXX)
add_executable(glcm glcm.cpp)
target_compile_features(glcm PRIVATE cxx_std_17)
