Rozbalte ZIP a v jeho složce spusťte příkazy.
Extract the ZIP and run these commands in its folder.

Python 3 (standard library):
python split.py

Výsledek / Output: crop 475/576, origin 117/576; predictions.csv.
