"""Reproduce both out-of-fold 1-NN experiments. Python 3, standard library."""
import csv
import math
import sys
from pathlib import Path

FEATURES = ("mean_r", "mean_g", "mean_b", "sd_r", "sd_g", "sd_b", "contrast_right", "contrast_down")

def predict_fold(rows, vectors, field, fold):
    train = [i for i,row in enumerate(rows) if int(row[field]) != fold]
    test = [i for i,row in enumerate(rows) if int(row[field]) == fold]
    means = [sum(vectors[i][k] for i in train)/len(train) for k in range(len(FEATURES))]
    variance = [sum((vectors[i][k]-m)**2 for i in train)/len(train) for k,m in enumerate(means)]
    scale = [math.sqrt(v) if v>0 else 1.0 for v in variance]
    z = [[(x-m)/s for x,m,s in zip(row,means,scale)] for row in vectors]
    for i in test:
        def key(j):
            return sum((a-b)**2 for a,b in zip(z[i],z[j])), rows[j]["id"]
        neighbour = min(train,key=key)
        yield i, neighbour, math.sqrt(key(neighbour)[0])

def run(source, output):
    with source.open(encoding="utf8") as f:
        rows=list(csv.DictReader(f))
    vectors=[[float(row[k]) for k in FEATURES] for row in rows]
    with output.open("w",newline="",encoding="utf8") as f:
        writer=csv.writer(f,lineterminator="\n")
        writer.writerow(["mode","fold","id","truth","prediction","nearest","distance","same_original"])
        for mode in ("crop","origin"):
            hits=0
            for fold in range(1,7):
                for i,j,distance in predict_fold(rows,vectors,"fold_"+mode,fold):
                    a,b=rows[i],rows[j]
                    hits += a["class_name"]==b["class_name"]
                    writer.writerow([mode,fold,a["id"],a["class_name"],b["class_name"],b["id"],
                                     distance,int(a["original"]==b["original"])])
            print(f"{mode}: {hits}/{len(rows)} = {100*hits/len(rows):.2f}%")

if __name__=="__main__":
    run(Path(sys.argv[1]) if len(sys.argv)>1 else Path("patches.csv"),
        Path(sys.argv[2]) if len(sys.argv)>2 else Path("predictions.csv"))
