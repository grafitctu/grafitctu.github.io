cmake_minimum_required(VERSION 3.16)
project(covariance LANGUAGES CXX)
add_executable(covariance covariance.cpp)
target_compile_features(covariance PRIVATE cxx_std_17)
