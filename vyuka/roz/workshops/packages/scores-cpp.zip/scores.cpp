// A two-region classroom example. Build with a C++17 compiler.
#include <algorithm>
#include <array>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>

using Mask = std::array<int, 16>;
using Table = std::array<std::array<int, 2>, 2>;

std::pair<double, double> scores(const Mask& truth, const Mask& prediction) {
    Table overlap{};
    std::array<int, 2> refSize{}, segSize{};
    for (std::size_t i = 0; i < truth.size(); ++i) {
        ++overlap[truth[i]][prediction[i]];
        ++refSize[truth[i]];
        ++segSize[prediction[i]];
    }
    int credited = 0;
    for (int g = 0; g < 2; ++g) {
        for (int p = 0; p < 2; ++p) {
            int n = overlap[g][p];
            if (4*n >= 3*refSize[g] && 4*n >= 3*segSize[p]) credited += n;
        }
    }
    // Match labels to maximise the total intersection. Enumerate the two possibilities.
    int bestTotal = -1;
    double bestWeightedIoU = 0;
    for (int first : {prediction.front(), 1-prediction.front()}) {
        int total = 0;
        double weightedIoU = 0;
        for (int g = 0; g < 2; ++g) {
            int p = g == 0 ? first : 1-first;
            int n = overlap[g][p];
            total += n;
            if (n) weightedIoU += double(refSize[g])*n/(refSize[g]+segSize[p]-n);
        }
        if (total > bestTotal) {
            bestTotal = total;
            bestWeightedIoU = weightedIoU;
        }
    }
    return {double(credited)/truth.size(), bestWeightedIoU/truth.size()};
}

int main() {
    Mask truth = {0,0,1,1, 0,0,1,1, 0,0,1,1, 0,0,1,1};
    for (const std::string mode : {"perfect","renamed","merged","exchange"}) {
        Mask prediction = truth;
        if (mode == "renamed") for (int& v : prediction) v = 1-v;
        if (mode == "merged") prediction.fill(0);
        if (mode == "exchange") std::swap(prediction[0],prediction[2]);
        auto [cs, ca] = scores(truth,prediction);
        std::cout << std::fixed << std::setprecision(6) << mode << " CS " << 100*cs << "% CA " << 100*ca << "%\n";
    }
}
