Rozbalte ZIP a v jeho složce spusťte příkazy.
Extract the ZIP and run these commands in its folder.

Linux / macOS:
c++ -std=c++17 -O2 scores.cpp -o scores
./scores

Windows (Developer PowerShell / x64 Native Tools for Visual Studio):
cl /nologo /EHsc /std:c++17 /O2 scores.cpp
.\scores.exe

4 × 4 pixels, two regions: perfect and renamed 100/100, merged 0/25, exchange 87.5/77.777778 (CS/CA, %).
