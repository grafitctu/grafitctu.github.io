import csv
import sys


def sample_covariance(rows):
    n = len(rows)
    if n < 2:
        raise ValueError("Sample covariance needs two or more observations")
    means = [sum(row[k] for row in rows) / n for k in range(2)]
    matrix = [[0.0, 0.0], [0.0, 0.0]]
    for x, y in rows:
        d = (x - means[0], y - means[1])
        for i in range(2):
            for j in range(2):
                matrix[i][j] += d[i] * d[j]
    return [[entry / (n - 1) for entry in row] for row in matrix]


def cooccurrence(levels, dx, dy):
    counts = [[0] * 4 for _ in range(4)]
    for y, row in enumerate(levels):
        for x, a in enumerate(row):
            nx, ny = x + dx, y + dy
            if 0 <= nx < len(row) and 0 <= ny < len(levels):
                b = levels[ny][nx]
                counts[a][b] += 1
    return counts


def neighbour_covariance(counts):
    cells = [(i, j, count) for i, row in enumerate(counts) for j, count in enumerate(row)]
    m = sum(count for i, j, count in cells)
    if m < 2:
        raise ValueError("Sample covariance needs two or more pairs")
    mean_a = sum(i * count for i, j, count in cells) / m
    mean_b = sum(j * count for i, j, count in cells) / m
    return sum(count * (i - mean_a) * (j - mean_b) for i, j, count in cells) / (m - 1)


def main(tile="stripes", order="original", direction="right"):
    offsets = {"right": (1, 0), "down": (0, 1), "left": (-1, 0), "right2": (2, 0)}
    if tile not in ("stripes", "bark") or order not in ("original", "shuffled") or direction not in offsets:
        raise ValueError("Use [stripes|bark] [original|shuffled] [right|down|left|right2]")
    with open("pixels.csv", newline="", encoding="ascii") as f:
        rows = [r for r in csv.DictReader(f) if r["tile"] == tile]
    key = (lambda r: int(r["shuffled_slot"])) if order == "shuffled" else (lambda r: 4 * int(r["y"]) + int(r["x"]))
    if sorted(key(r) for r in rows) != list(range(16)):
        raise ValueError("Expected 16 distinct pixel positions")
    pixels = [tuple(int(r[c]) for c in ("r", "g", "b")) for r in sorted(rows, key=key)]
    if any(v < 0 or v > 255 for pixel in pixels for v in pixel):
        raise ValueError("Pixel channels must be between 0 and 255")
    channels = [(r // 64, g // 64) for r, g, b in pixels]
    grey = [(r + g + b) // 192 for r, g, b in pixels]
    levels = [grey[i:i + 4] for i in range(0, 16, 4)]
    counts = cooccurrence(levels, *offsets[direction])
    print("S")
    for row in sample_covariance(channels):
        print(*(f"{v:.6f}" for v in row))
    print("C")
    for row in counts:
        print(*row)
    print("pairs", sum(map(sum, counts)))
    print("cov(A,B)", f"{neighbour_covariance(counts):.6f}")


if __name__ == "__main__":
    main(*sys.argv[1:])
