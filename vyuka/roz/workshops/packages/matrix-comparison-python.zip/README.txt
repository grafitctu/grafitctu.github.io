Kovarianční a kookurenční matice / Covariance and co-occurrence matrices

Rozbalte ZIP a spusťte příkaz v jeho složce. Program vypíše výběrovou kovarianci kanálů R a G, orientovanou GLCM a výběrovou kovarianci sousedních jasů.
Extract the ZIP and run the command in its folder. The program prints sample R,G covariance, directed GLCM counts and sample covariance of neighbouring grey levels.

S[i,j] = sum_k (x[k,i] - mean[i]) * (x[k,j] - mean[j]) / (n - 1), k = 1..n.
Pro barevné pruhy je n = 4 × 4 = 16 pixelů. Po převodu na úrovně 0–3 má osm pixelů (R,G) = (2,0) a osm (1,3). Oba průměry jsou 24/16 = 1,5. Součiny odchylek jsou 0,5 × (−1,5) a (−0,5) × 1,5, oba −0,75. Přes všechny pixely vyjde 8 × (−0,75) + 8 × (−0,75) = −12. Výběrová kovariance je −12 / (16 − 1) = −0,8.
For the stripes, n = 4 × 4 = 16 pixels. After quantisation to levels 0–3, eight pixels have (R,G) = (2,0) and eight have (1,3). Both means equal 24/16 = 1.5. The products are 0.5 × (−1.5) and (−0.5) × 1.5, both −0.75. Adding across all pixels gives 8 × (−0.75) + 8 × (−0.75) = −12. The sample covariance is −12 / (16 − 1) = −0.8.

Python 3
python compare.py
python compare.py bark shuffled down

Arguments: [stripes|bark] [original|shuffled] [right|down|left|right2]

pixels.csv: x a y začínají od nuly. Sloupec shuffled_slot určuje novou pozici celého pixelu při promíchání (po řádcích). Kůra je výřez 4 × 4 od x=56, y=35 z bark10_t0-00, školní datová sada Mosaic Colour [normal] CL.
Pixel x and y start at zero. shuffled_slot gives the new row-major position of the whole pixel. Bark is a 4 × 4 excerpt at x=56, y=35 from bark10_t0-00 in the course Mosaic Colour [normal] CL dataset.
