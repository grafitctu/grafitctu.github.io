// Fisher LDA — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Vector learn_fisher_direction(const Matrix& X_train, const std::vector<int>& y_train) {
    // Binary Fisher LDA: solve (within-class scatter + ridge*I) w = mu1-mu0.
    double ridge = 1e-6;
    return fisher_direction(X_train, y_train, ridge); // unit-length direction
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix train=load_csv(data+"/train.csv"); std::vector<int> y_train;
        for(auto& x:train){y_train.push_back(int(x.back()));x.pop_back();}
        std::cout << "{\"direction\":"; json_vector(std::cout,learn_fisher_direction(train,y_train));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
