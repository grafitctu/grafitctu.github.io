"""DBSCAN / DBSCAN — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.cluster import DBSCAN

def find_clusters(X):
    return DBSCAN(eps=0.18, min_samples=6).fit_predict(X)
    # min_samples includes the point itself; -1 means noise.

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")
    labels = find_clusters(X)
    result = {"clusters": len(set(labels)-{-1}), "noise": int((labels == -1).sum()), "labels": labels.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
