"""Rekonstrukce z hlavních složek / Reconstruction from principal components — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA

def reconstruct(fitted_model, X, k):
    directions = fitted_model.components_[:k]
    scores = (X - fitted_model.mean_) @ directions.T
    return fitted_model.mean_ + scores @ directions

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")
    k = 1  # Try 0, 1, 2. / Zkuste 0, 1, 2.
    model = PCA(n_components=X.shape[1], svd_solver="full").fit(X)
    reconstruction = reconstruct(model, X, k)
    result = {"k": k, "mse": float(np.mean((X-reconstruction)**2)), "retained_fraction": float(model.explained_variance_ratio_[:k].sum()), "reconstruction": reconstruction.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
