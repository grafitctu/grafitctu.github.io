"""Radiální příznak / Radial feature — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np


def add_radial_feature(X):
    radius_squared = np.sum(X * X, axis=1)
    return np.c_[X, radius_squared]  # explicit map, not an RBF kernel

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")[:, :2]
    result = {"mapped_points": add_radial_feature(X).tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
