// PCA on training data — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Matrix pca_experiment(const Matrix& X_train, const Matrix& X_validation) {
    // Learn the mean and directions from training data only.
    auto pca = fit_pca_variance(X_train, 0.95);
    Matrix Z_train = pca.transform(X_train);
    Matrix Z_validation = pca.transform(X_validation);
    Matrix X_reconstructed = pca.inverse_transform(Z_validation);
    return X_reconstructed;
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix X_train=load_csv(data+"/train.csv"), X_validation=load_csv(data+"/validation.csv");
        for(auto& x:X_train)x.pop_back(); for(auto& x:X_validation)x.pop_back();
        const Matrix reconstruction=pca_experiment(X_train,X_validation);
        std::cout << "{\"train_samples\":" << X_train.size() << ",\"validation_samples\":" << X_validation.size();
        std::cout << ",\"mse\":" << mse(X_validation,reconstruction) << ",\"reconstruction\":"; json_matrix(std::cout,reconstruction);
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
