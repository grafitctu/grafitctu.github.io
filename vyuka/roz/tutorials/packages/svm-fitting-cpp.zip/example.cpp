// Fitting an SVM — NI-ROZ / ANI-ROZ
#include "svm_model.hpp"
using namespace roz;

std::vector<int> classify(const Matrix& X_train, const std::vector<int>& y_train,
                          const Matrix& X_validation) {
    double C = 1.0, gamma = 1.0;
    auto model = fit_svm(X_train, y_train, "rbf", C, gamma);
    return model.predict(X_validation); // LIBSVM trains the actual SVM
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix train=load_csv(data+"/train.csv"),test=load_csv(data+"/test.csv"); std::vector<int> y_train,y_test;
        for(auto& x:train){y_train.push_back(int(x.back()));x.pop_back();} for(auto& x:test){y_test.push_back(int(x.back()));x.pop_back();}
        const auto predicted=classify(train,y_train,test); std::size_t correct=0;
        for(std::size_t i=0;i<predicted.size();++i)if(predicted[i]==y_test[i])++correct;
        std::cout << "{\"train_samples\":" << train.size() << ",\"test_samples\":" << test.size() << ",\"accuracy\":" << double(correct)/predicted.size();
        std::cout << ",\"predictions\":"; json_vector(std::cout,as_numbers(predicted));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
