// Projection onto a chosen axis — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Vector project_on_axis(const Matrix& X, double angle_degrees) {
    Vector mu = mean(X);
    Matrix A = centered(X, mu);
    double theta = angle_degrees * std::acos(-1.0) / 180.0;
    Vector u{std::cos(theta), std::sin(theta)}; // unit direction
    Vector scores;
    for (const auto& x : A) scores.push_back(dot(x, u));
    return scores;
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        const Matrix X=load_csv(data+"/points.csv"); const double angle=35.0;
        const Vector scores=project_on_axis(X,angle);
        std::cout << "{\"angle_degrees\":" << angle << ",\"sample_variance\":" << dot(scores,scores)/double(scores.size()-1);
        std::cout << ",\"scores\":"; json_vector(std::cout,scores);
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
