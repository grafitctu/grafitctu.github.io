// DBSCAN — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

std::vector<int> find_clusters(const Matrix& X) {
    double epsilon = 0.18;
    std::size_t min_samples = 6; // the point itself counts
    std::vector<int> labels = dbscan(X, epsilon, min_samples);
    return labels; // -1 means noise; nonnegative values identify clusters
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        const Matrix X=load_csv(data+"/points.csv"); const auto labels=find_clusters(X);
        int largest=-1,noise=0; for(int label:labels){largest=std::max(largest,label);if(label==-1)++noise;}
        std::cout << "{\"clusters\":" << largest+1 << ",\"noise\":" << noise << ",\"labels\":"; json_vector(std::cout,as_numbers(labels));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
