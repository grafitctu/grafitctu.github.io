"""Projekce na zvolenou osu / Projection onto a chosen axis — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np


def project_on_axis(X, angle_degrees):
    mu = X.mean(axis=0)
    centered = X - mu
    theta = np.deg2rad(angle_degrees)
    u = np.array([np.cos(theta), np.sin(theta)])
    return centered @ u

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")
    angle = 35.0
    scores = project_on_axis(X, angle)
    result = {"angle_degrees": angle, "sample_variance": float(scores.var(ddof=1)), "scores": scores.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
