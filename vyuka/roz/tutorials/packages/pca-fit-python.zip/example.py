"""Výpočet PCA a vlastních čísel / Fitting PCA and eigenvalues — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA

def learn_pca(X_train, k):
    return PCA(n_components=k, svd_solver="full").fit(X_train)

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")
    model = learn_pca(X, X.shape[1])
    result = {"mean": model.mean_.tolist(), "covariance": np.cov(X, rowvar=False, ddof=1).tolist(), "eigenvalues": model.explained_variance_.tolist(), "directions_as_rows": model.components_.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
