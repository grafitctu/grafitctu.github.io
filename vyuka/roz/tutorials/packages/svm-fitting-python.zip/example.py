"""Učení SVM / Fitting an SVM — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.svm import SVC

def classify(X_train, y_train, X_validation):
    model = SVC(kernel="rbf", C=1.0, gamma=1.0)
    model.fit(X_train, y_train)
    return model.predict(X_validation)

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    train, test = read("train.csv"), read("test.csv")
    X_train, y_train = train[:, :2], train[:, -1].astype(int)
    X_test, y_test = test[:, :2], test[:, -1].astype(int)
    predicted = classify(X_train, y_train, X_test)
    result = {"train_samples": len(X_train), "test_samples": len(X_test), "accuracy": float(np.mean(predicted == y_test)), "predictions": predicted.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
