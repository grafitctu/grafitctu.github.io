"""PCA na trénovacích datech / PCA on training data — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.decomposition import PCA

def pca_experiment(X_train, X_validation):
    # Learn the mean and directions from training data only.
    pca = PCA(n_components=0.95, svd_solver="full")
    Z_train = pca.fit_transform(X_train)
    Z_validation = pca.transform(X_validation)
    X_reconstructed = pca.inverse_transform(Z_validation)
    return X_reconstructed

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X_train = read("train.csv")[:, :2]
    X_validation = read("validation.csv")[:, :2]
    reconstruction = pca_experiment(X_train, X_validation)
    result = {"train_samples": len(X_train), "validation_samples": len(X_validation), "mse": float(np.mean((X_validation-reconstruction)**2)), "reconstruction": reconstruction.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
