// Scaler → PCA → SVM — NI-ROZ / ANI-ROZ
#include "svm_model.hpp"
using namespace roz;

std::vector<int> training_pipeline(const Matrix& X_train, const std::vector<int>& y_train,
                                   const Matrix& X_validation) {
    auto scaler = fit_scaler(X_train); // divisor n, like StandardScaler
    Matrix A_train = scaler.transform(X_train);
    Matrix A_validation = scaler.transform(X_validation);
    auto pca = fit_pca_variance(A_train, 0.95); // sample covariance uses n-1
    Matrix Z_train = pca.transform(A_train);
    Matrix Z_validation = pca.transform(A_validation);
    auto model = fit_svm(Z_train, y_train, "rbf", 1.0, 1.0);
    return model.predict(Z_validation); // no fitting on validation or test
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix train=load_csv(data+"/train.csv"),test=load_csv(data+"/test.csv"); std::vector<int> y_train,y_test;
        for(auto& x:train){y_train.push_back(int(x.back()));x.pop_back();} for(auto& x:test){y_test.push_back(int(x.back()));x.pop_back();}
        const auto predicted=training_pipeline(train,y_train,test); std::size_t correct=0;
        for(std::size_t i=0;i<predicted.size();++i)if(predicted[i]==y_test[i])++correct;
        std::cout << "{\"train_samples\":" << train.size() << ",\"test_samples\":" << test.size() << ",\"accuracy\":" << double(correct)/predicted.size();
        std::cout << ",\"predictions\":"; json_vector(std::cout,as_numbers(predicted));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
