// Reconstruction from principal components — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Matrix reconstruct(const Pca& fitted_model, const Matrix& X, std::size_t k) {
    Pca model = fitted_model; // reuse the fitted mean and directions
    require(k <= model.directions.size(), "Too many components.");
    model.k = k;
    Matrix Z = model.transform(X);
    return model.inverse_transform(Z); // k=0 returns the training mean
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        const Matrix X=load_csv(data+"/points.csv"); const std::size_t k=1; // Try 0, 1, 2.
        auto model=fit_pca(X,dimensions(X)); const Matrix reconstruction=reconstruct(model,X,k); model.k=k;
        std::cout << "{\"k\":" << k << ",\"mse\":" << mse(X,reconstruction) << ",\"retained_fraction\":" << model.retained_fraction();
        std::cout << ",\"reconstruction\":"; json_matrix(std::cout,reconstruction);
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
