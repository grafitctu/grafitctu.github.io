"""Kovarianční matice 3 × 3 / 3 × 3 covariance matrix — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np


def sample_covariance(X):
    X = np.asarray(X, dtype=float)  # rows = samples, columns = features
    if X.ndim != 2 or len(X) < 2 or not np.isfinite(X).all():
        raise ValueError("Use at least two finite samples.")
    centered = X - X.mean(axis=0)
    return centered.T @ centered / (len(X) - 1)

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")
    C = sample_covariance(X)
    values, vectors = np.linalg.eigh(C)
    order = np.argsort(values)[::-1]
    result = {"n": len(X), "mean": X.mean(axis=0).tolist(), "centered": (X-X.mean(axis=0)).tolist(), "covariance": C.tolist(), "eigenvalues": np.maximum(values[order], 0).tolist(), "directions_as_rows": vectors[:, order].T.tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
