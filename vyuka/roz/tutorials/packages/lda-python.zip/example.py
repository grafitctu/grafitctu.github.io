"""Fisherova LDA / Fisher LDA — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np


def learn_fisher_direction(X_train, y_train):
    groups = [X_train[y_train == label] for label in (0, 1)]
    means = [group.mean(axis=0) for group in groups]
    scatter = sum((group - mu).T @ (group - mu)
                  for group, mu in zip(groups, means))
    ridge = 1e-6
    w = np.linalg.solve(scatter + ridge * np.eye(X_train.shape[1]),
                        means[1] - means[0])
    return w / np.linalg.norm(w)

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    train = read("train.csv")
    X_train, y_train = train[:, :2], train[:, -1].astype(int)
    result = {"direction": learn_fisher_direction(X_train, y_train).tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
