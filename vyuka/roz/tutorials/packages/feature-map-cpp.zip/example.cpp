// Radial feature — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Matrix add_radial_feature(const Matrix& X) {
    Matrix mapped;
    for (const auto& x : X) {
        double radius_squared = x[0]*x[0] + x[1]*x[1];
        mapped.push_back({x[0], x[1], radius_squared});
    }
    return mapped; // an explicit feature map, not an RBF kernel
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix X=load_csv(data+"/points.csv"); for(auto& x:X)x.pop_back();
        std::cout << "{\"mapped_points\":"; json_matrix(std::cout,add_radial_feature(X));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
