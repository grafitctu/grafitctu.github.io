// Matrix × vector — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Vector matrix_times_vector(const Matrix& A, const Vector& v) {
    Vector w(A.size(), 0.0);
    for (std::size_t i = 0; i < A.size(); ++i)
        for (std::size_t j = 0; j < v.size(); ++j)
            w[i] += A[i][j] * v[j];
    return w;
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        const Matrix A=load_csv(data+"/matrix.csv"); const Vector v=load_csv(data+"/vector.csv").front();
        require(dimensions(A)==v.size(), "Matrix/vector dimensions differ.");
        std::cout << "{\"matrix\":"; json_matrix(std::cout,A);
        std::cout << ",\"vector\":"; json_vector(std::cout,v);
        std::cout << ",\"result\":"; json_vector(std::cout,matrix_times_vector(A,v));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
