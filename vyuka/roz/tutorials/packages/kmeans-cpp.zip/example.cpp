// K-means — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Kmeans find_kmeans(const Matrix& X) {
    Matrix initial_centres{X.front(), X.back()};
    Kmeans result = kmeans(X, initial_centres, 100);
    return result; // centres and labels; empty clusters keep their centres
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        Matrix X=load_csv(data+"/points.csv"); for(auto& x:X)x.pop_back();
        std::cout << "{\"labels\":"; json_vector(std::cout,as_numbers(find_kmeans(X).labels));
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
