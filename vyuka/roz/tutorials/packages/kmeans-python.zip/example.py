"""K-means / K-means — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np
from sklearn.cluster import KMeans

def find_kmeans(X):
    initial_centres = X[[0, -1]]
    model = KMeans(n_clusters=2, init=initial_centres, n_init=1,
                   max_iter=100, algorithm="lloyd")
    return model.fit_predict(X)

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    X = read("points.csv")[:, :2]
    result = {"labels": find_kmeans(X).tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
