"""Matice × vektor / Matrix × vector — NI-ROZ / ANI-ROZ."""
import json
import sys
from pathlib import Path
import numpy as np


def matrix_times_vector(A, v):
    A = np.asarray(A, dtype=float)
    v = np.asarray(v, dtype=float)
    return A @ v

BASE = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent / "data"
def read(name):
    return np.loadtxt(BASE/name, delimiter=",", skiprows=1, ndmin=2)

if __name__ == "__main__":
    A = read("matrix.csv")
    v = read("vector.csv")[0]
    result = {"matrix": A.tolist(), "vector": v.tolist(), "result": matrix_times_vector(A, v).tolist()}
    print(json.dumps(result, indent=2, ensure_ascii=False))
