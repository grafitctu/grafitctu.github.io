// Fitting PCA and eigenvalues — NI-ROZ / ANI-ROZ
#include "recognition.hpp"
using namespace roz;

Pca learn_pca(const Matrix& X_train, std::size_t k) {
    // fit_pca computes sample covariance, eigenvectors and eigenvalues.
    // Its readable implementation is in recognition.hpp.
    Pca model = fit_pca(X_train, k);
    return model; // mean, unit directions, variances, component count
}

int main(int argc, char** argv) {
    try {
        const std::string data=argc>1?argv[1]:"data";
        std::cout << std::setprecision(17);
        const Matrix X=load_csv(data+"/points.csv"); const auto model=learn_pca(X,dimensions(X));
        std::cout << "{\"mean\":"; json_vector(std::cout,model.mu);
        std::cout << ",\"covariance\":"; json_matrix(std::cout,covariance(X));
        std::cout << ",\"eigenvalues\":"; json_vector(std::cout,model.variances);
        std::cout << ",\"directions_as_rows\":"; json_matrix(std::cout,model.directions);
        std::cout << "}\n";
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
