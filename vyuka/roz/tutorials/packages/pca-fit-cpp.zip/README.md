# Výpočet PCA a vlastních čísel / Fitting PCA and eigenvalues — C++17

Česky: rozbalte celý ZIP do vlastní složky a spusťte příkazy z této složky.
English: extract the entire ZIP into its own folder and run the commands from that folder.

`example.cpp` obsahuje funkci ze slidů a spustitelnou ukázku. Data jsou ve složce `data`.
The source contains the function from the slides and a runnable example. Input data are in `data`.

## Spuštění / Run

```sh
cmake -S . -B build
cmake --build build --config Release

# Linux / macOS
./build/roz_pca_fit

# Windows — PowerShell, Visual Studio generator
.\build\Release\roz_pca_fit.exe
```

Windows: Visual Studio 2022 s C++ workloadem a CMake; otevřete Developer PowerShell for VS nebo tuto složku ve Visual Studiu. Linux/macOS: C++17 a CMake; lze také spustit `make`.
Windows: use Visual Studio 2022 with its C++ workload and CMake, in Developer PowerShell for VS or by opening this folder in Visual Studio. Linux/macOS: a C++17 compiler and CMake; GNU `make` is also supported.

Podpůrné výpočty jsou v `recognition.hpp`. Python k této variantě nepotřebujete.
Supporting calculations are in `recognition.hpp`. This variant does not require Python.

## Vstup a výstup / Input and output

CSV má první řádek s hlavičkou. Souřadnice jsou `x1,x2`; třetí sloupec `label`, pokud je přítomen, obsahuje třídu 0 nebo 1.
CSV files start with a header. Features are `x1,x2`; an optional third column `label` contains class 0 or 1.
Program vypíše výsledek jako JSON do terminálu. Data nebo parametry můžete měnit v přiloženém zdrojovém kódu.
The program prints its result as JSON in the terminal. Edit the included source and CSV files to try other parameters or data.
Jiný adresář dat lze zadat jako první argument programu.
A different data directory can be passed as the first command-line argument.

PCA používá výběrovou kovarianci (dělitel n−1); MSE je průměr přes všechny původní hodnoty. Opačné znaménko vlastního vektoru představuje stejnou osu.
PCA uses sample covariance (divisor n−1); MSE averages over all original values. Opposite eigenvector signs describe the same axis.

## Zdroje / Sources

https://grafitctu.github.io/vyuka/roz/tutorials/
