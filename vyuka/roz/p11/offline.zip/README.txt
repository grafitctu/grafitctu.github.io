ROZ 11 - Michal Haindl 2023-2024
Open p11/index.html or p11/commented.html. Both editions and original PDF are included. Keep shared/ and p11/ next to each other.
