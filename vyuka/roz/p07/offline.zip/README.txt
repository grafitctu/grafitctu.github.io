ROZ 07 - Michal Haindl 2023-2024
Open p07/index.html or p07/commented.html. Both editions and original PDF are included. Keep shared/ and p07/ next to each other.
