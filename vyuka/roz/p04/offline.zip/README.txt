ROZ 04 - Michal Haindl 2023-2024
Open p04/index.html or p04/commented.html. Both editions and original PDF are included. Keep shared/ and p04/ next to each other.
