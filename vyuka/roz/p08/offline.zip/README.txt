ROZ 08 - Michal Haindl 2023-2024
Open p08/index.html or p08/commented.html. Both editions and original PDF are included. Keep shared/ and p08/ next to each other.
