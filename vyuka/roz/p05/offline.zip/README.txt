ROZ 05 - Michal Haindl 2023-2024
Open p05/index.html or p05/commented.html. Both editions and original PDF are included. Keep shared/ and p05/ next to each other.
